package com.example.demo;

import java.math.BigDecimal;
import java.util.List;
import com.example.demo.layer2.VehicleTable;
import com.example.demo.layer3.VehicleRepository;
import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;



@SpringBootTest
public class VehicleTest  {
	@Autowired
	VehicleRepository VehicleRepo;

	@Test
	void addNewVehicleTest() {
		VehicleTable newVehicle = new VehicleTable();
		//newLoan.setLoanAmount(100000);
		newVehicle.setCarCompany("Hyundai");
		newVehicle.setCarModel("Alcazer");
		newVehicle.setShowroomPrice(BigDecimal.valueOf(2500000));
		newVehicle.setOnRoadPrice(BigDecimal.valueOf(2800000));
		//base.persist(newDept);
		VehicleRepo.insertVehicle(newVehicle); 
		System.out.println("Working");
	}
	@Test
	public void selectAllVehicles() {
		List<VehicleTable> list = VehicleRepo.selectAllVehicles();
		for(VehicleTable a:list) {
			System.out.println(a.getCarCompany());
			System.out.println(a.getCarModel());
			System.out.println(a.getOnRoadPrice());
			System.out.println(a.getShowroomPrice());
			System.out.println("----------");
		}
	}
	@Test
	public void updateVehicleTest() {
		 VehicleTable updateVehicle = VehicleRepo.selectVehicleByVehicleid(203);
			if(updateVehicle!=null) {
		VehicleTable newVehicle = new VehicleTable();
		newVehicle.setVehicleId(203);
		newVehicle.setCarCompany("Tata");
		newVehicle.setCarModel("Indigo");
		newVehicle.setShowroomPrice(BigDecimal.valueOf(2400000));
		newVehicle.setOnRoadPrice(BigDecimal.valueOf(2900000));
		VehicleRepo.updateVehicle(newVehicle);}
	}
	
	@Test
	public void selectAVehicleTest() {
		
		VehicleTable a = VehicleRepo.selectVehicleByVehicleid(101);
		System.out.println(a.getCarCompany());
		System.out.println(a.getCarModel());
		System.out.println(a.getOnRoadPrice());
		System.out.println(a.getShowroomPrice());
		System.out.println("----------");
	}
 
	@Test
	void deleteVehicleTest() {
	  try {
		  VehicleTable delVehicle = VehicleRepo.selectVehicleByVehicleid(203);
			if(delVehicle!=null) {
			System.out.println("Car description: "+delVehicle.getCarCompany()+" "+delVehicle.getCarModel());
			
		  VehicleRepo.deleteVehicle(203);
	       System.out.println("Object deleted..");
	       }}
	  catch(Exception e) {
            System.out.println(e.getMessage());
	        }
	}
	
	
}