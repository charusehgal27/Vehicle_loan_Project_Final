package com.example.demo;

import java.math.BigDecimal;
import java.util.List;

import com.example.demo.layer2.UserTable;
import com.example.demo.layer3.UserRepository;
import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class UserTest {
	@Autowired
	UserRepository userRepo;

	@Test
	void addNewUserTest() {
		UserTable newUser = new UserTable();
		//newLoan.setLoanAmount(100000);
		newUser.setAddress("MoCity1");
		System.out.println("1");
		newUser.setAge(BigDecimal.valueOf(21.0));
		System.out.println("2");
		newUser.setCity("Califia11");
		System.out.println("3");
		newUser.setEmailId("cha111@gmail.com");
		System.out.println("4");
		newUser.setFirstName("Charu1");
		System.out.println("5");
		newUser.setMiddleName("S1");
		System.out.println("6");
		newUser.setLastName("Sehga1l");
		System.out.println("7");
		newUser.setGender("Female");
		System.out.println("8");
		newUser.setMobileNumber(BigDecimal.valueOf(896542311));
		System.out.println("9");
		newUser.setPincode(BigDecimal.valueOf(286154));
		System.out.println("10");
		newUser.setState("UP1");
		System.out.println("11");
		newUser.setUserPassword("ch356781");
		System.out.println("12");
		//base.persist(newDept);
		userRepo.insertUser(newUser);
		System.out.println("Working");
	}
	@Test
	public void selectAUser() {
		//UserTable selectUser = new UserTable();
		UserTable selectUser=userRepo.selectUserByUserid(1);
		System.out.println(selectUser.getFirstName());
		System.out.println(selectUser.getMiddleName());
		System.out.println(selectUser.getLastName());
		System.out.println(selectUser.getEmailId());
		System.out.println(selectUser.getAddress());
		System.out.println(selectUser.getCity());
		System.out.println(selectUser.getState());
		System.out.println(selectUser.getState());
		System.out.println(selectUser.getAge());
		System.out.println(selectUser.getGender());
		System.out.println(selectUser.getUserPassword());
		System.out.println(selectUser.getMobileNumber());
	}
	
	@Test
	public void selectAllUser() {
		List<UserTable> list = userRepo.selectAllUsers();
		for(UserTable selectAll:list) {
			
			System.out.println(selectAll.getFirstName());
			System.out.println(selectAll.getMiddleName());
			System.out.println(selectAll.getLastName());
			System.out.println(selectAll.getEmailId());
			System.out.println(selectAll.getAddress());
			System.out.println(selectAll.getCity());
			System.out.println(selectAll.getState());
			System.out.println(selectAll.getState());
			System.out.println(selectAll.getAge());
			System.out.println(selectAll.getGender());
			System.out.println(selectAll.getUserPassword());
			System.out.println(selectAll.getMobileNumber());
		}
	}
	@Test
	public void updateAUser() {
		
		UserTable updateUser = new UserTable();
	 updateUser = userRepo.selectUserByUserid(2);
		if(updateUser!=null) {
		updateUser.setUserId(2);
		updateUser.setAddress("MoonCity_LTI");
		updateUser.setAge(BigDecimal.valueOf(40.0));
		updateUser.setCity("California_LTI");
		updateUser.setEmailId("charu_LTI@gmail.com");
		updateUser.setFirstName("Charu_I");
		updateUser.setMiddleName("SS");
		updateUser.setLastName("Sehgal");
		updateUser.setGender("Female");
		updateUser.setMobileNumber(BigDecimal.valueOf(896754231));
		updateUser.setPincode(BigDecimal.valueOf(286754));
		updateUser.setState("UP_LTI");
		updateUser.setUserPassword("charu35678");
		//base.persist(newDept);
		userRepo.updateUser(updateUser);
		System.out.println("Working");}
	}
	@Test
	void deleteAUser() {
		UserTable delUser = userRepo.selectUserByUserid(1);
		if(delUser!=null) {
		System.out.println("User Name: "+delUser.getFirstName()+" "+delUser.getLastName());		
		userRepo.deleteUser(1);
		System.out.println("Object Deleted");}
		else {
		System.out.println("object not found");
		}
	}
}
