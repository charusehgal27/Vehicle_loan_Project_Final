package com.example.demo.layer4.test;

import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.UserTable;
import com.example.demo.layer3.UserRepository;
import com.example.demo.layer4.UserService;

@SpringBootTest
public class UserServiceTest {

	@Autowired
	UserService userService;

	@Test
	public void findUserByIdServiceTest() {
		int userId = 1;

		UserTable user1 = userService.findUserbyIdService(userId);
		System.out.println(user1.getFirstName());
		System.out.println(user1.getMiddleName());
		System.out.println(user1.getLastName());
		System.out.println(user1.getAddress());
		System.out.println(user1.getState());
		System.out.println(user1.getCity());
		System.out.println(user1.getPincode());
		System.out.println(user1.getGender());
		System.out.println(user1.getAge());
		System.out.println(user1.getUserPassword());
		System.out.println(user1.getMobileNumber());
		System.out.println(user1.getEmailId());
	}

	@Test
	public void findAllUsersServiceTest() {
		List<UserTable> users = userService.findAllUsersService();
		for (UserTable a : users) {
			System.out.println(a.getFirstName());
			System.out.println(a.getMiddleName());
			System.out.println(a.getLastName());
			System.out.println(a.getAddress());
			System.out.println(a.getState());
			System.out.println(a.getCity());
			System.out.println(a.getPincode());
			System.out.println(a.getGender());
			System.out.println(a.getAge());
			System.out.println(a.getUserPassword());
			System.out.println(a.getMobileNumber());
			System.out.println(a.getEmailId());
			System.out.println("----------");
		}
	}

	@Test
	public void addNewUserServiceTest() {
		UserTable user = new UserTable();

		user.setAddress("MoonC_LTI");
		user.setAge(BigDecimal.valueOf(40.0));
		user.setCity("Califor_LTI");
		user.setEmailId("charuLTI@gmail.com");
		user.setFirstName("CharuLTI");
		user.setMiddleName("SS");
		user.setLastName("Sehgal");
		user.setGender("Female");
		user.setMobileNumber(BigDecimal.valueOf(996754231));
		user.setPincode(BigDecimal.valueOf(186754));
		user.setState("UPLTI");
		user.setUserPassword("charu5678");
		userService.insertUserService(user);
	}

	@Test
	public void updateUserServiceTest() {
		UserTable user = userService.findUserbyIdService(107);
		user.setUserId(107);
		user.setAddress("KailashResidency");
		user.setAge(BigDecimal.valueOf(20.0));
		user.setCity("Pune");
		user.setEmailId("charu1@gmail.com");
		user.setFirstName("CharuSS");
		userService.updateUserService(user);
	}

	@Test
	public void deleteUserServiceTest() {
		try {
			UserTable user = userService.findUserbyIdService(107);
			if (user != null) {
				userService.deleteUserService(107);
				System.out.println("User deleted");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
}

/*
 * @Test public void findlocationServiceTest() {
 * //System.out.println("Enter dept number : "); //scan.nextInt(); int dno=20;
 * String location;
 * 
 * try {
 * 
 * location = deptService.findDepartmentLocationByDeptNo(dno);
 * System.out.println("Location of dept no "+dno+" is "+location); } catch
 * (DeptNotFoundException e) { // TODO Auto-generated catch block
 * //e.printStackTrace(); System.out.println(e.getMessage()); }
 * 
 * }
 */