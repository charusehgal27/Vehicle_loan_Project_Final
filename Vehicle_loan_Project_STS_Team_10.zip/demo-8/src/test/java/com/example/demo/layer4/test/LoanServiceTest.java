package com.example.demo.layer4.test;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.LoanTable;
import com.example.demo.layer3.LoanRepository;
import com.example.demo.layer4.LoanService;

@SpringBootTest
public class LoanServiceTest {
	
	@Autowired
	LoanService loanService;
	
	@Test
	public void findLoanByIdServiceTest() {
		int loanId=405;
		
		LoanTable loan1=loanService.findLoanbyIdService(loanId);
		System.out.println(loan1.getLoanId());
		System.out.println(loan1.getLoanAmount());
		System.out.println(loan1.getLoanTenure());
		System.out.println(loan1.getProcessingFee());
		System.out.println(loan1.getRateOfInterest());
	}
	
	@Test
	public void findAllLoansServiceTest() {
		List<LoanTable> loans= loanService.findAllLoansService();
		for(LoanTable a:loans) {
			System.out.println(a.getLoanId());
			System.out.println(a.getLoanAmount());
			System.out.println(a.getLoanTenure());
			System.out.println(a.getProcessingFee());
			System.out.println(a.getRateOfInterest());
			System.out.println("----------");
		}
	}
	
	@Test
	public void addNewLoanServiceTest() {
		LoanTable loan =new LoanTable();
		loan.setLoanAmount(BigDecimal.valueOf(800000.0));
		loan.setLoanTenure(BigDecimal.valueOf(3.0));
		loan.setProcessingFee(BigDecimal.valueOf(1600.0));
		loan.setRateOfInterest(BigDecimal.valueOf(4.7));
		loanService.insertLoanService(loan);
	}
	
	@Test
	public void updateLoanServiceTest() {
		LoanTable loan=loanService.findLoanbyIdService(127);
		loan.setLoanTenure(BigDecimal.valueOf(9.0));
		loan.setRateOfInterest(BigDecimal.valueOf(6.7));
		loanService.updateLoanService(loan);
	}
	
	@Test
	public void deleteLoanServiceTest() {
		try {
		LoanTable loan=loanService.findLoanbyIdService(129);
		if(loan!=null) {
			loanService.deleteLoanService(129);
			System.out.println("loan deleted");
		   }
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
	     }

    }
}


/*@Test
public void findlocationServiceTest() {
//System.out.println("Enter dept number : ");
//scan.nextInt();
	  int dno=20;
	  String location;
	  
	  try {
		  
	  location = deptService.findDepartmentLocationByDeptNo(dno);
	  System.out.println("Location of dept no "+dno+" is "+location);
	  } catch (DeptNotFoundException e) {
	  // TODO Auto-generated catch block
	  //e.printStackTrace();
	  System.out.println(e.getMessage());
	  }

	  }
*/