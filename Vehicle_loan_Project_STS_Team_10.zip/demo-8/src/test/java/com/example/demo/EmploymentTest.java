package com.example.demo;

import java.math.BigDecimal;
import java.util.List;

import com.example.demo.layer2.EmploymentTable;
import com.example.demo.layer3.EmploymentRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class EmploymentTest {

	@Autowired
	EmploymentRepository EmpRepo;
	
	@Test
	void addNewEmpTest() {
		EmploymentTable newEmployee = new EmploymentTable();
		
		newEmployee.setEmpType("Salaried");
		newEmployee.setAnnualSalary(BigDecimal.valueOf(700000.0));
		newEmployee.setExistingEmi(BigDecimal.valueOf(5000));
		EmpRepo.insertEmployee(newEmployee);
		System.out.println("Working");
	}
	
	@Test
	public void selectAllEmpsTest() {
		List<EmploymentTable> list = EmpRepo.selectAllEmployees();
		for(EmploymentTable a:list) {
			System.out.println(a.getEmploymentId());
			System.out.println(a.getEmpType());
			System.out.println(a.getAnnualSalary());
			System.out.println(a.getExistingEmi());
			System.out.println("----------");
		}
	}
	
	@Test
	public void updateEmpTest() {
		
		EmploymentTable newEmployee = new EmploymentTable();
		newEmployee= EmpRepo.selectEmployeeByEmployeeId(401);
		newEmployee.setEmploymentId(302);
		newEmployee.setEmpType("Salaried");
		newEmployee.setAnnualSalary(BigDecimal.valueOf(700000.0));
		newEmployee.setExistingEmi(BigDecimal.valueOf(5000));
	    EmpRepo.updateEmployee(newEmployee);
	}
	
	@Test
	void deleteEmpTest() {
	  try {
		  EmpRepo.deleteEmployee(305);
	       System.out.println("Object deleted..");
	       }
	  catch(Exception e) {
            System.out.println(e.getMessage());
	        }
	}
	
	@Test
	public void selectAEmpTest() {
		
		EmploymentTable a = EmpRepo.selectEmployeeByEmployeeId(302);
		System.out.println(a.getEmploymentId());
		System.out.println(a.getEmpType());
		System.out.println(a.getAnnualSalary());
		System.out.println(a.getExistingEmi());
	}
}