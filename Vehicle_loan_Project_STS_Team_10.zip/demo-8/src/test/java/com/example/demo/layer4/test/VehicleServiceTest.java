package com.example.demo.layer4.test;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.VehicleTable;
import com.example.demo.layer4.VehicleService;

@SpringBootTest
public class VehicleServiceTest {

	@Autowired
	VehicleService vehicleService;
	
	@Test
	public void findVehicleByIdServiceTest() {
		
		VehicleTable vehicle1=vehicleService.findVehiclebyIdService(203);
		System.out.println(vehicle1.getCarCompany());
		System.out.println(vehicle1.getCarModel());
		System.out.println(vehicle1.getShowroomPrice());
		System.out.println(vehicle1.getOnRoadPrice());

		
	}
}