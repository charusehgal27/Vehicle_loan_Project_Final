package com.example.demo;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.example.demo.layer2.ApplicationTable;
import com.example.demo.layer2.BankTable;
import com.example.demo.layer2.CibilTable;
import com.example.demo.layer2.EmploymentTable;
import com.example.demo.layer2.LoanTable;
import com.example.demo.layer2.UserTable;
import com.example.demo.layer2.VehicleTable;
import com.example.demo.layer3.AppRepository;
import com.example.demo.layer3.BankRepository;
import com.example.demo.layer3.CibilRepository;
import com.example.demo.layer3.EmploymentRepository;
import com.example.demo.layer3.UserRepository;
import com.example.demo.layer3.VehicleRepository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Repository;

@SpringBootTest
public class ApplicationTest {
	@Autowired
	AppRepository AppRepo;
	@Autowired
	BankRepository BankRepo;
	@Autowired
	CibilRepository CibilRepo;
	@Autowired
	VehicleRepository VehicleRepo;
	@Autowired
	UserRepository UserRepo;
	@Autowired
	EmploymentRepository EmploymentRepo;

	
	@Test
	void addNewAppTest() throws ParseException {
		
		UserTable theUser= UserRepo.selectUserByUserid(1);
		//List<ApplicationTable>allApps=theUser.getApplicationTables();
		ApplicationTable newApp = new ApplicationTable();

		
		SimpleDateFormat format = new SimpleDateFormat("dd-mm-yyyy");
		Date date1 = format.parse("20-08-2021");

		VehicleTable newVehicle= new VehicleTable();
		EmploymentTable newEmployee=new EmploymentTable();
		LoanTable newLoan=new LoanTable();
		BankTable newBank=new BankTable();
		CibilTable newCibil1= new CibilTable();
		



		/*
		UserTable newUser=new UserTable();
		CibilTable newCibil = CibilRepo.selectCibilByPancard("P3");
		*/
		
		//application table
		newApp.setDateOfApplication(date1);
		newApp.setDateOfApproval(date1);
		newApp.setLoanStatus("Approved");
		
		
		//vehicle table
		newVehicle.setCarCompany("Hyundai");
		newVehicle.setCarModel("Verna");
		newVehicle.setShowroomPrice(BigDecimal.valueOf(800000));
		newVehicle.setOnRoadPrice(BigDecimal.valueOf(1000000));
		newVehicle.setApplicationTable(newApp);
		
		//emp details
		newEmployee.setEmpType("Salaried");
		newEmployee.setAnnualSalary(BigDecimal.valueOf(7005000.0));
		newEmployee.setExistingEmi(BigDecimal.valueOf(50500));
		newEmployee.setApplicationTable(newApp);
		
		
		//loan table
				newLoan.setLoanAmount(BigDecimal.valueOf(6050000.0));
				newLoan.setLoanTenure(BigDecimal.valueOf(55.0));
				newLoan.setProcessingFee(BigDecimal.valueOf(25000.0));
				newLoan.setRateOfInterest(BigDecimal.valueOf(6.55));
				newLoan.setApplicationTable(newApp);
				
				
		//bank table
				newBank.setAccNumber(BigDecimal.valueOf(1005058));
				newBank.setIfscCode("BKID008724");
				newCibil1.setPancardNumber("P252");
				newCibil1.setCibilScore(BigDecimal.valueOf(750));
				newBank.setCibilTable(newCibil1);
				newBank.setApplicationTable(newApp);
					
		
		
		newApp.setVehicleTable(newVehicle);// 1 fk
		newApp.setEmploymentTable(newEmployee); //2 fk
		newApp.setLoanTable(newLoan);  // 3 fk
		newApp.setBankTable(newBank);   // 4 fk
		
		List<ApplicationTable> allApps=new ArrayList<ApplicationTable>();

		theUser.setApplicationTables(allApps);
		allApps.add(newApp);
		
		//theUser.setApplicationTables(allApps);
		
		
		AppRepo.insertApp(newApp);
		//UserRepo.insertUser(theUser);
		System.out.println("Working");
		
		
	}

	@Test
	void selectAllAppTest() {
		List<ApplicationTable> dp1 = AppRepo.selectAllApp();
		for (ApplicationTable d1 : dp1) {
			System.out.println(d1.getApplicationId());			
			System.out.println(d1.getLoanStatus());
			System.out.println(d1.getDateOfApplication());
			System.out.println(d1.getDateOfApproval());		
			VehicleTable vic = d1.getVehicleTable();
			System.out.println("Vehicle ID : "+vic.getVehicleId());
			UserTable uic = d1.getUserTable();
			System.out.println("User ID : "+uic.getUserId());			
			EmploymentTable eic = d1.getEmploymentTable();
			System.out.println("Vehicle ID : "+eic.getEmploymentId());			
			LoanTable lic = d1.getLoanTable();
			System.out.println("Loan ID : "+lic.getLoanId());			
			BankTable bic = d1.getBankTable();
			System.out.println("Bank ID : "+bic.getBankId());			
			System.out.println("====================");
		}
	}
	
	@Test
	public void selectAAppByAppNoTest() {

		ApplicationTable a = AppRepo.selectAppByAppNo(801);
		LoanTable l = a.getLoanTable();
		EmploymentTable e = a.getEmploymentTable();
		VehicleTable v = a.getVehicleTable();
		BankTable b = a.getBankTable();
		CibilTable c = b.getCibilTable();

		System.out.println("Application Id : "+ a.getApplicationId());
		System.out.println("Date of application " + a.getDateOfApplication());
		System.out.println("LoanStatus: " + a.getLoanStatus());
		System.out.println("DateOfApproval : " + a.getDateOfApproval());
		System.out.println("=================�");

		System.out.println("Loan Id : "+ l.getLoanId());
		System.out.println("LoanAmount : " + l.getLoanAmount());
		System.out.println("LoanTenure : " + l.getLoanTenure());
		System.out.println("RateOfInterest : " + l.getRateOfInterest());
		System.out.println("ProcessingFee : " + l.getProcessingFee());
		System.out.println("=================�");

		System.out.println("Employment Id : "+ e.getEmploymentId());
		System.out.println("EmpType : " + e.getEmpType());
		System.out.println("AnnualSalary : " + e.getAnnualSalary());
		System.out.println("ExistingEmi : " + e.getExistingEmi());
		System.out.println("=================�");

		System.out.println("Vehicle Id : "+ v.getVehicleId());
		System.out.println("CarCompany : " + v.getCarCompany());
		System.out.println("CarModel : " + v.getCarModel());
		System.out.println("OnRoadPrice : " + v.getOnRoadPrice());
		System.out.println("ShowroomPrice: " + v.getShowroomPrice());
		System.out.println("=================�");

		System.out.println("Bank Id : "+ b.getBankId());
		System.out.println("AccNumber: " + b.getAccNumber());
		System.out.println("IfscCode : " + b.getIfscCode());
		System.out.println("=================�");


		System.out.println("CibilScore : " + c.getCibilScore());
		System.out.println("PancardNumber: " + c.getPancardNumber());
		System.out.println("=================�");

	}
	
	@Test
	public void deleteAAppByAppNoTest() {
		
		try {
			ApplicationTable delApp = AppRepo.selectAppByAppNo(805);
			if(delApp!=null) {
				AppRepo.deleteApp(805);
				System.out.println("Object deleted..");
			}}
			catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void updateAAppByAppNoTest() {
		
		try {
			ApplicationTable updateApp = AppRepo.selectAppByAppNo(139);
			if(updateApp!=null) {
				BankTable upBank =updateApp.getBankTable();
				updateApp.setLoanStatus("saasproved");
				upBank.setIfscCode("aaaaaadddd");
				//upBank.setApplicationTable(updateApp);
				//BankRepo.updateBank(upBank);
				updateApp.setBankTable(upBank);
				AppRepo.updateApp(updateApp);
				System.out.println("Object updated..");
			}}
			catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
}