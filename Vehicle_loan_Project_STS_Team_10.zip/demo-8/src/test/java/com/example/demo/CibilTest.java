package com.example.demo;

import java.math.BigDecimal;
import java.util.List;

import com.example.demo.layer2.CibilTable;
import com.example.demo.layer3.CibilRepository;

import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;



@SpringBootTest
class CibilTest {
	
	@Autowired
	CibilRepository CibilRepo;

	@Test
	void addNewCibilTest() {
		CibilTable newCibil = new CibilTable();
		//newCibil.setCibilAmount(100000);
		newCibil.setCibilScore(BigDecimal.valueOf(500));

		newCibil.setPancardNumber("P11");
		
		CibilRepo.insertCibil(newCibil);
		System.out.println("Working");
	}
	
	
	@Test
	void selectAllCibilTest() {
		List<CibilTable> cList= CibilRepo.selectAllCibil();
		System.out.println("Selected All Department Rows");
		System.out.println("====================");
		for(CibilTable civ:cList)
		{
			System.out.println(civ.getPancardNumber());
			System.out.println(civ.getCibilScore());
			System.out.println("====================");
		}
	}
	
	@Test
	public void selectACibilTest() {
		
		CibilTable a = CibilRepo.selectCibilByPancard("P11");
		System.out.println(a.getPancardNumber());
		System.out.println(a.getCibilScore());
	}
	
	@Test
	public void updateCibilTest() {
		
		CibilTable newCibil = CibilRepo.selectCibilByPancard("P11");
		if(newCibil!=null)
		{
			newCibil.setCibilScore(BigDecimal.valueOf(750));
			newCibil.setPancardNumber("P12");
			CibilRepo.updateCibil(newCibil);
		}
		else
			System.out.println("Not found");
	}
	
	
	@Test
	void deleteCibilTest() {
	CibilTable delCibil = CibilRepo.selectCibilByPancard("P11");
	if(delCibil!=null)
	{
		CibilRepo.deleteCibil("P11");
		System.out.println("Object Deleted");
	}
	else
		System.out.println("Entry not found");
	}
}