package com.example.demo.layer4.test;

import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.BankTable;
import com.example.demo.layer2.CibilTable;
import com.example.demo.layer3.BankRepository;
import com.example.demo.layer4.BankService;

@SpringBootTest
public class BankServiceTest {

	@Autowired
	BankService bankService;

	@Test
	public void findBankByIdServiceTest() {
		int bankId = 501;

		BankTable bank1 = bankService.findBankbyIdService(bankId);
		System.out.println(bank1.getAccNumber());
		System.out.println(bank1.getIfscCode());
		System.out.println(bank1.getBankId());
		
		//CibilTable c =new CibilTable();
		CibilTable c=bank1.getCibilTable();
		System.out.println(c.getCibilScore());
		System.out.println(c.getPancardNumber());
		
	}

	@Test
	public void findAllBanksServiceTest() {
		List<BankTable> banks = bankService.findAllBanksService();
		for (BankTable a : banks) {
			System.out.println(a.getAccNumber());
			System.out.println(a.getIfscCode());
			System.out.println(a.getBankId());
			CibilTable c=a.getCibilTable();
			System.out.println(c.getCibilScore());
			System.out.println(c.getPancardNumber());
			System.out.println("----------");
		}
	}

	@Test
	public void addNewBankServiceTest() {
		BankTable bank = new BankTable();

		
		bank.setAccNumber(BigDecimal.valueOf(32986752));
		bank.setIfscCode("123456783");
		CibilTable c = new CibilTable();
		//c=bank.getCibilTable();
		c.setPancardNumber("P20");
		c.setCibilScore(BigDecimal.valueOf(800));
		//c.setBankTable(bank);
		bank.setCibilTable(c);
		bankService.insertBankService(bank);
		System.out.println("Working................");
	}

	@Test
	public void updateBankServiceTest() {
		BankTable bank = bankService.findBankbyIdService(502);
		bank.setBankId(502);
		bank.setAccNumber(BigDecimal.valueOf(123));;
		bank.setIfscCode(null);
		//CibilTable c = new CibilTable();
		//c.setPancardNumber("P20");
		//c.setCibilScore(BigDecimal.valueOf(800));
		//c.setBankTable(bank);
		//bank.setCibilTable(c);
		bankService.updateBankService(bank);
		System.out.println("Working");
	}
	
	@Test
	public void deleteBankServiceTest() {
		try {
			BankTable bank = bankService.findBankbyIdService(505);
			if (bank != null) {
				bankService.deleteBankService(505);
				System.out.println("Bank deleted");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
}























//this is of no need as we are only giving I have just done for trial
// in updation one sahitya is not even calling any update function nor other tables hes isupdating may be because other things can be updated from their table as well , but insertion should be done combinedly in all so we are complete insertion I will ask him once ok