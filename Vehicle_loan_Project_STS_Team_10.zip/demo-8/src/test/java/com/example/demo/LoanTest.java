package com.example.demo;

import java.math.BigDecimal;
import java.util.List;
import com.example.demo.layer2.LoanTable;
import com.example.demo.layer3.LoanRepository;
import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;



@SpringBootTest
class LoanTests {
	@Autowired
	LoanRepository LoanRepo;

	@Test
	void addNewLoanTest() {
		LoanTable newLoan = new LoanTable();
		//newLoan.setLoanAmount(100000);
		newLoan.setLoanAmount(BigDecimal.valueOf(10000.0));
		newLoan.setLoanTenure(BigDecimal.valueOf(5.0));
		newLoan.setProcessingFee(BigDecimal.valueOf(2000.0));
		newLoan.setRateOfInterest(BigDecimal.valueOf(6.5));
		//base.persist(newDept);
		LoanRepo.insertLoan(newLoan);
		System.out.println("Working");
	}

 @Test
	public void selectAllLoans() {
		List<LoanTable> list = LoanRepo.selectAllLoans();
		for(LoanTable a:list) {
			System.out.println(a.getLoanId());
			System.out.println(a.getLoanAmount());
			System.out.println(a.getLoanTenure());
			System.out.println(a.getProcessingFee());
			System.out.println(a.getRateOfInterest());
			System.out.println("----------");
		}
	}
	
	@Test
	public void updateLoanTest() {
		 LoanTable newLoan = LoanRepo.selectLoanByLoanId(404);
			if(newLoan!=null) {
		newLoan.setLoanId(404);
		newLoan.setLoanAmount(BigDecimal.valueOf(60000000));
		newLoan.setLoanTenure(BigDecimal.valueOf(5.0));
		newLoan.setProcessingFee(BigDecimal.valueOf(1500));
		newLoan.setRateOfInterest(BigDecimal.valueOf(6.7));
		LoanRepo.updateLoan(newLoan);}
	}
	
	@Test
	void deleteLoanTest() {
	  try {
		  LoanTable delLoan = LoanRepo.selectLoanByLoanId(403);
			if(delLoan!=null) {
			System.out.println("Loan Amount: "+delLoan.getLoanAmount());
			
		  LoanRepo.deleteLoan(403);
	       System.out.println("Object deleted..");
	       }
			else {
				System.out.println("object not found");
				}
		}
	  catch(Exception e) {
            System.out.println("Catch is running"+e.getMessage());
	        }
	}
	
	@Test
	public void selectALoanTest() {
		
		LoanTable a = LoanRepo.selectLoanByLoanId(84);
		System.out.println(a.getLoanId());
		System.out.println(a.getLoanAmount());
		System.out.println(a.getLoanTenure());
		System.out.println(a.getProcessingFee());
		System.out.println(a.getRateOfInterest());
	}
}















//	
//	@Test
//	void selectAllDepartmentTest() {
//
//					
//					List<Dept> dp1= deptRepo.selectAllDepts();
//					System.out.println("Selected All Department Rows");
//
//					System.out.println("====================");
//					for(Dept d1:dp1)
//						{
//						System.out.println(d1.getDeptno());
//						System.out.println(d1.getDname());
//						System.out.println(d1.getLoc());
//						System.out.println("====================");
//						}
//					
//
//	}
//
//	@Test
//	void selectDepartmentByDNOTest() {
//
//					
//					Dept dp1= deptRepo.selectDeptByDeptNo(26);
//					System.out.println("Selected Department Row with Deptno= "+dp1.getDeptno());
//
//					System.out.println("====================");
//					System.out.println(dp1.getDeptno());
//					System.out.println(dp1.getDname());
//					System.out.println(dp1.getLoc());
//					System.out.println("====================");
//				
//					
//
//	}
//
//	@Test
//	void updateDepartmentTest() {
//
//					Dept dp1= new Dept();
//					dp1.setDeptno(61);
//					dp1.setDname("HR");
//					dp1.setLoc("Navi Mumbai");
//					
//					deptRepo.updateDept(dp1);
//					System.out.println("Updated Department Row");
//					System.out.println("====================");
//					System.out.println(dp1.getDeptno());
//					System.out.println(dp1.getDname());
//					System.out.println(dp1.getLoc());
//					System.out.println("====================");
//	}
//
//	@Test
//	public void deleteDeptTest() {
//		
//		//Dept delDept = deptRepo.selectDeptByDeptNo(21);
//		try {
//			deptRepo.deleteDept(61);
//			System.out.println("Deleted Department Row");
//		}
//		catch(Exception e) {
//			System.out.println(e.getMessage());
//		}
//		
////		System.out.println("====================");
////		System.out.println(delDept.getDeptno());
////		System.out.println(delDept.getDname());
////		System.out.println(delDept.getLoc());
////		System.out.println("====================");
//		
//	}
//
//}
//	
//}
