package com.example.demo.layer4.test;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.ApplicationTable;
import com.example.demo.layer4.ApplicationService;

@SpringBootTest
public class ApplicationServiceTest {
	
	@Autowired
	ApplicationService applicationService;
	
	@Test
	public void findApplicationbyIdService() {
		int appId=801;
		
		ApplicationTable app1=applicationService.findApplicationbyIdService(appId);
		System.out.println(app1.getApplicationId());
		System.out.println(app1.getLoanStatus());
		System.out.println(app1.getDateOfApplication());
		System.out.println(app1.getDateOfApproval());
		System.out.println(app1.getLoanTable());

	}
}