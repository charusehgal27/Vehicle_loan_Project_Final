package com.example.demo;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;

import com.example.demo.layer2.ApplicationTable;
import com.example.demo.layer2.BankTable;
import com.example.demo.layer2.CibilTable;
import com.example.demo.layer3.BankRepository;
import com.example.demo.layer3.CibilRepository;

import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankTest {
	@Autowired
	BankRepository BankRepo;
	@Autowired
	CibilRepository CibilRepo;

	@Test
	void addNewBankToExistingCibilTest() {
		BankTable newBank = new BankTable();
		CibilTable newCibil = new CibilTable();
		// newLoan.setLoanAmount(100000);
		newCibil.setPancardNumber("P11");
		newBank.setAccNumber(BigDecimal.valueOf(1250000));
		newBank.setIfscCode("BKID002104");
		newBank.setCibilTable(newCibil);

		BankRepo.insertBank(newBank);
		System.out.println("Working");
	}

	@Test
	void addNewBankWithNewCibil() {

		BankTable newBank = new BankTable();
		newBank.setAccNumber(BigDecimal.valueOf(400));
		newBank.setIfscCode("dsfsdfsdfdsfssd5214");

		CibilTable civ1 = new CibilTable("P15", BigDecimal.valueOf(800));

		CibilRepo.insertCibil(civ1);
		newBank.setCibilTable(civ1); // 3 rows added

		BankRepo.insertBank(newBank); // 3 time update

	}

	@Test
	void selectAllBankTest() {
		List<BankTable> bList = BankRepo.selectAllBanks();

		System.out.println("Selected All BankTable Rows");
		System.out.println("====================");
		for (BankTable ban : bList) {
			System.out.println(ban.getBankId());
			System.out.println(ban.getIfscCode());
			System.out.println(ban.getAccNumber());
			CibilTable civ = ban.getCibilTable();
			System.out.println("Pan Number : " + civ.getPancardNumber());
			System.out.println("Cibil Score : " + civ.getCibilScore());

			System.out.println("====================");
		}
	}

	@Test
	public void selectABankByBankIdTest() {

		BankTable a = BankRepo.selectBankByBankId(501);
		CibilTable civ = a.getCibilTable();

		System.out.println("Account number " + a.getAccNumber());
		System.out.println("Pan Number : " + civ.getPancardNumber());
		System.out.println("=================�");

	}

	@Test
	public void updateBankTest() {

		BankTable a = BankRepo.selectBankByBankId(501);
		CibilTable civ = a.getCibilTable();
		a.setAccNumber(BigDecimal.valueOf(4011));
		civ.setPancardNumber("P12");
		civ.setCibilScore(BigDecimal.valueOf(900));
		CibilRepo.insertCibil(civ);
		BankRepo.updateBank(a);

		// newCibil.setBankTable(a);
		BankRepo.updateBank(a);
		// CibilRepo.updateCibil(newCibil);
	}

	@Test
	public void deleteBankByBankIdTest() {

		try {
			BankTable delBank = BankRepo.selectBankByBankId(162);
			if (delBank != null) {
				BankRepo.deleteBank(162);
				System.out.println("Object deleted..");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}