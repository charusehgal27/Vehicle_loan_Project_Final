package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.VehicleTable;


@Service
public interface VehicleService {

	VehicleTable findVehiclebyIdService(int VehicleId);
	List<VehicleTable> findAllVehiclesService();
	void insertVehicleService(VehicleTable vref);
	void updateVehicleService(VehicleTable vref);
	void deleteVehicleService(int VehicleId);
}