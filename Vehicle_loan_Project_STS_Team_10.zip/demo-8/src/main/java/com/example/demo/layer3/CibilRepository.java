package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.CibilTable;

@Repository
public interface CibilRepository {
	
	void insertCibil(CibilTable CRef);
	CibilTable selectCibilByPancard(String PanNum);
	List<CibilTable> selectAllCibil();
	void updateCibil(CibilTable CRef);
	void deleteCibil(String PanNum);
	

}