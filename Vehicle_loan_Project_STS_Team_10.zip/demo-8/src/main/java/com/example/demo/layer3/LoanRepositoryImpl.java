package com.example.demo.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.LoanTable;

@Repository
public class LoanRepositoryImpl extends BaseRepository implements LoanRepository {
	
	public LoanRepositoryImpl() {
		System.out.println("LoanRepositoryImpl() implementation");
	}

	@Transactional
	public void insertLoan(LoanTable lRef) {
		// TODO Auto-generated method stub
		super.persist(lRef);

	}

	@Transactional
	public LoanTable selectLoanByLoanId(int loanId) {
		// TODO Auto-generated method stub
		return super.find(LoanTable.class, loanId);
	}

	@Transactional
	public List<LoanTable> selectAllLoans() {
		// TODO Auto-generated method stub
		return super.findAll("LoanTable");
	}

	@Transactional
	public void updateLoan(LoanTable lRef) {
		// TODO Auto-generated method stub
		super.merge(lRef);

	}

	@Transactional
	public void deleteLoan(int loanId) {
		// TODO Auto-generated method stub
		super.remove(LoanTable.class, loanId);

	}

}