package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.LoanTable;
import com.example.demo.layer3.LoanRepository;

@Service
public class LoanServiceImpl implements LoanService {

	@Autowired
	LoanRepository loanRepo;
	
	@Override
	public LoanTable findLoanbyIdService(int loanId) {
		// TODO Auto-generated method stub
		return loanRepo.selectLoanByLoanId(loanId);
	}

	@Override
	public List<LoanTable> findAllLoansService() {
		// TODO Auto-generated method stub
		return loanRepo.selectAllLoans();
	}

	@Override
	public void insertLoanService(LoanTable lref) {
		// TODO Auto-generated method stub
        loanRepo.insertLoan(lref);
	}

	@Override
	public void updateLoanService(LoanTable lref) {
		// TODO Auto-generated method stub
        loanRepo.updateLoan(lref);
	}

	@Override
	public void deleteLoanService(int loanId) {
		// TODO Auto-generated method stub
        loanRepo.deleteLoan(loanId);
	}

}