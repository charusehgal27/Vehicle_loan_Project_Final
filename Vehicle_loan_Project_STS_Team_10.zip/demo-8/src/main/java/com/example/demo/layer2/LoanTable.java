package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;


/**
 * The persistent class for the LOAN_TABLE database table.
 * 
 */
@Entity
@Table(name="LOAN_TABLE")
@NamedQuery(name="LoanTable.findAll", query="SELECT l FROM LoanTable l")
public class LoanTable implements Serializable {
	private static final int serialVersionUID = 1;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LOAN_ID")
	private int loanId;

	@Column(name="LOAN_AMOUNT")
	private BigDecimal loanAmount;

	@Column(name="LOAN_TENURE")
	private BigDecimal loanTenure;

	@Column(name="PROCESSING_FEE")
	private BigDecimal processingFee;

	@Column(name="RATE_OF_INTEREST")
	private BigDecimal rateOfInterest;

	//bi-directional one-to-one association to ApplicationTable
	@OneToOne(mappedBy="loanTable",cascade= CascadeType.ALL)
	private ApplicationTable applicationTable;

	public LoanTable() {
	}

	public int getLoanId() {
		return this.loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public BigDecimal getLoanAmount() {
		return this.loanAmount;
	}

	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}

	public BigDecimal getLoanTenure() {
		return this.loanTenure;
	}

	public void setLoanTenure(BigDecimal loanTenure) {
		this.loanTenure = loanTenure;
	}

	public BigDecimal getProcessingFee() {
		return this.processingFee;
	}

	public void setProcessingFee(BigDecimal processingFee) {
		this.processingFee = processingFee;
	}

	public BigDecimal getRateOfInterest() {
		return this.rateOfInterest;
	}

	public void setRateOfInterest(BigDecimal rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	@JsonIgnore
	public ApplicationTable getApplicationTable() {
		return this.applicationTable;
	}

	public void setApplicationTable(ApplicationTable applicationTable) {
		this.applicationTable = applicationTable;
	}

}