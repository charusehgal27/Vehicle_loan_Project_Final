package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.BankTable;


@Repository
public interface BankRepository {
	
	void insertBank(BankTable BRef);
	BankTable selectBankByBankId(int Bid);
	List<BankTable> selectAllBanks();
	void updateBank(BankTable BRef);
	void deleteBank(int Bid);

}