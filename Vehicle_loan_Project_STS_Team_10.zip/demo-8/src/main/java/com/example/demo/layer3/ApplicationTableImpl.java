package com.example.demo.layer3;
import com.example.demo.layer2.ApplicationTable;

import org.springframework.stereotype.Repository;
import java.util.List;

import javax.transaction.Transactional;
@Repository
public class ApplicationTableImpl extends BaseRepository implements AppRepository {

	@Transactional
	public List<ApplicationTable> selectQuery(String query) {
	return super.findAll(query);
	}
	
	@Transactional
	public void insertApp(ApplicationTable ARef) {
		super.persist(ARef);
	}

	@Transactional
	public ApplicationTable selectAppByAppNo(int Ano) {
		return super.find(ApplicationTable.class, Ano);
	}

	@Transactional
	public List<ApplicationTable> selectAllApp() {
		return super.findAll("ApplicationTable");
	}

	@Transactional
	public void updateApp(ApplicationTable ARef) {
		super.merge(ARef);
	}

	@Transactional
	public void deleteApp(int Ano) {
		super.remove(ApplicationTable.class,Ano);
	}

}
