package com.example.demo.layer5;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.VehicleTable;
import com.example.demo.layer4.VehicleService;


@CrossOrigin(origins="", value="")
@RestController
public class VehicleJPAController {

	@Autowired
	VehicleService vehicleService;
	
	public VehicleJPAController() {
		System.out.println("VehicleJPAController....");
	}
	
	@GetMapping
	@RequestMapping(path="/getJPAVehicles")  //localhost:8080/getJPAVehicles
	public List<VehicleTable> getAllVehicles(){
		System.out.println("get all vehicless");
		return vehicleService.findAllVehiclesService();
	}
	
	@GetMapping
	@RequestMapping(path="/getJPAVehicle/{vno}") //localhost:8080/getJPAVehicle/203
	public VehicleTable getVehicle(@PathVariable("vno")int vehicleToFind)throws VehicleNotFoundException
	{
		System.out.println("Get vehicle details of "+vehicleToFind);
		VehicleTable foundVehicle=null;
		foundVehicle=vehicleService.findVehiclebyIdService(vehicleToFind);
		
		if(foundVehicle==null) {
			System.out.println("vehicle not found");
			VehicleNotFoundException vehicleException= new VehicleNotFoundException("Vehicle "+vehicleToFind+" not found");
		}
		return foundVehicle;
	}
	
	@PostMapping
	@RequestMapping(path="/addJPAVehicle") 
	public void addVehicle(@RequestBody VehicleTable vehicleInsert)throws VehicleNotFoundException
	{
	    
		VehicleTable newVehicle =new VehicleTable();
		newVehicle.setCarCompany(vehicleInsert.getCarCompany());
		newVehicle.setCarModel(vehicleInsert.getCarModel());
		newVehicle.setShowroomPrice(vehicleInsert.getShowroomPrice());
		newVehicle.setOnRoadPrice(vehicleInsert.getOnRoadPrice());
		vehicleService.insertVehicleService(newVehicle);
	}
	
	@PostMapping
	@RequestMapping(path="/updateJPAVehicle")
	public void updateVehicle(@RequestBody VehicleTable vehicleUpdate)throws VehicleNotFoundException
	{
	
		System.out.println("updating record "+vehicleUpdate.getVehicleId());
		boolean found=false;
		vehicleService.updateVehicleService(vehicleUpdate);
        found=true;
		
		if(found)
		{ System.out.println("record updated");
			}
		else {
			System.out.println("not found");
			VehicleNotFoundException a= new VehicleNotFoundException("Loan "+vehicleUpdate.getVehicleId()+" not found");
		    throw a;	
		}
	}
	@PostMapping
	@RequestMapping(path="/deleteJPAVehicle")
	public void deleteVehicle(@RequestBody VehicleTable vehicleDelete)throws VehicleNotFoundException
	{
		System.out.println("updating record "+vehicleDelete.getVehicleId());
		boolean found=false;
		vehicleService.deleteVehicleService(vehicleDelete.getVehicleId());
		found=true;
		
		
		if(found) {
			System.out.println("record found");
		}
		else {
			try {
				System.out.println("record not found");
				VehicleNotFoundException a= new VehicleNotFoundException("vehicle "+vehicleDelete.getVehicleId()+" not found");
				throw a;
			} catch (VehicleNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("Caught exception");
				e.printStackTrace();
			}
		}
		
	}
	
	 
	
}