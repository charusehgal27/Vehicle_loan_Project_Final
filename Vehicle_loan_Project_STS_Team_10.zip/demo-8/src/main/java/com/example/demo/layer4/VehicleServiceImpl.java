package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.VehicleTable;
import com.example.demo.layer3.VehicleRepository;

@Service
public class VehicleServiceImpl implements VehicleService {

	@Autowired
	VehicleRepository vehicleRepo;
	
	@Override
	public VehicleTable findVehiclebyIdService(int VehicleId) {
		// TODO Auto-generated method stub
		return vehicleRepo.selectVehicleByVehicleid(VehicleId);
	}

	@Override
	public List<VehicleTable> findAllVehiclesService() {
		// TODO Auto-generated method stub
		return vehicleRepo.selectAllVehicles();
	}

	@Override
	public void insertVehicleService(VehicleTable vref) {
		// TODO Auto-generated method stub
		vehicleRepo.insertVehicle(vref);
	}

	@Override
	public void updateVehicleService(VehicleTable vref) {
		// TODO Auto-generated method stub
		vehicleRepo.updateVehicle(vref);
	}

	@Override
	public void deleteVehicleService(int VehicleId) {
		// TODO Auto-generated method stub
		vehicleRepo.deleteVehicle(VehicleId);
	}

}