package com.example.demo.layer5;

public class IdNotFoundException extends Exception {
	 public IdNotFoundException(String msg) {
		super(msg);
	}
}