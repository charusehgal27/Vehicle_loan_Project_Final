package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;


/**
 * The persistent class for the BANK_TABLE database table.
 * 
 */
@Entity
@Table(name="BANK_TABLE")
@NamedQuery(name="BankTable.findAll", query="SELECT b FROM BankTable b")
public class BankTable implements Serializable {
	//private static final int serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="BANK_ID")
	private int bankId;

	@Column(name="ACC_NUMBER")
	private BigDecimal accNumber;

	@Column(name="IFSC_CODE")
	private String ifscCode;

	//bi-directional one-to-one association to ApplicationTable
	@OneToOne(mappedBy="bankTable",cascade = CascadeType.ALL)
	private ApplicationTable applicationTable;

	//bi-directional one-to-one association to CibilTable
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="PANCARD_NUMBER")
	private CibilTable cibilTable;

	public BankTable() {
	}

	public int getBankId() {
		return this.bankId;
	}

	public void setBankId(int bankId) {
		this.bankId = bankId;
	}

	public BigDecimal getAccNumber() {
		return this.accNumber;
	}

	public void setAccNumber(BigDecimal accNumber) {
		this.accNumber = accNumber;
	}

	public String getIfscCode() {
		return this.ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	@JsonIgnore
	public ApplicationTable getApplicationTable() {
		return this.applicationTable;
	}

	public void setApplicationTable(ApplicationTable applicationTable) {
		this.applicationTable = applicationTable;
	}

	public CibilTable getCibilTable() {
		return this.cibilTable;
	}

	public void setCibilTable(CibilTable cibilTable) {
		this.cibilTable = cibilTable;
	}

}