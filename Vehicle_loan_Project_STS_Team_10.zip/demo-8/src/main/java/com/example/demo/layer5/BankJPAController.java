package com.example.demo.layer5;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.layer2.BankTable;
import com.example.demo.layer2.CibilTable;
import com.example.demo.layer4.BankService;

@CrossOrigin(origins = "", value = "")
@RestController
public class BankJPAController {

	@Autowired
	BankService BankService;

	public BankJPAController() {
		System.out.println("BankJPAController()....");
	}

	@GetMapping
	@RequestMapping(path = "/getJPABanks") // localhost:8080/getJPABanks
	public List<BankTable> getAllBanks() {
		System.out.println("get all Banks");

		return BankService.findAllBanksService();
	}

	@GetMapping
	@RequestMapping(path = "/getJPABank/{lno}") // localhost:8080/getJPABank/401
	public BankTable getBank(@PathVariable("lno") int BanktoFind) throws BankNotFoundException {
		System.out.println("get Bank: " + BanktoFind);
		BankTable foundBank = null;
		foundBank = BankService.findBankbyIdService(BanktoFind);

		if (foundBank == null) {
			BankNotFoundException l = new BankNotFoundException("Bank " + BanktoFind + " not found");
		}

		return foundBank;
	}

	@PostMapping
	@RequestMapping(path = "/deleteBank")
	public void deleteBank(@RequestBody BankTable Bank) throws BankNotFoundException {
		System.out.println("delete Bank " + Bank.getBankId());
		boolean found = false;
		BankService.deleteBankService(Bank.getBankId());
		found = true;

		if (found) {
			System.out.println("record updated");
		} else {
			System.out.println("not found");
			BankNotFoundException l = new BankNotFoundException("Bank " + Bank.getBankId() + " not found");
			throw l;
		}
	}

	@PostMapping
	@RequestMapping(path = "/addJPABank")
	public void addBank2(@RequestBody BankTable BankInsert) throws BankNotFoundException {
		BankTable newBank = new BankTable();
		newBank.setAccNumber(BankInsert.getAccNumber());
		newBank.setIfscCode(BankInsert.getIfscCode());
		// CibilTable c=newBank.getCibilTable();
		// c.setCibilScore(c.getCibilScore());//
		// c.setPancardNumber(c.getPancardNumber());//
		// newBank.setCibilTable(c);
		// newBank.setCibilTable(BankInsert.getCibilTable());
		BankService.insertBankService(newBank);
	}

	@PostMapping
	@RequestMapping(path = "/updateJPABank")
	public void updateBank(@RequestBody BankTable BankUpdate) throws BankNotFoundException {
		System.out.println("update Bank for: " + BankUpdate.getBankId());
		boolean found = false;
		BankService.updateBankService(BankUpdate);
		found = true;

		if (found) {
			System.out.println("record updated");
		} else {
			System.out.println("not found");
			BankNotFoundException l = new BankNotFoundException("Bank " + BankUpdate.getBankId() + " not found");
			throw l;
		}
	}

}

/*
 * @PostMapping
 * 
 * @RequestMapping(path="/addBank/{accNumber}/{ifscCode}/") public void
 * addBank(@PathVariable("accNumber")BigDecimal
 * BankAccount,@PathVariable("ifscCode")BigDecimal
 * BankTenure,@PathVariable("roi")BigDecimal rateOfInterest
 * ,@PathVariable("pfee")BigDecimal processingFee)throws BankNotFoundException {
 * System.out.println("Add Bank "+BankAmt+" "+BankTenure+" "+rateOfInterest+" "
 * +processingFee); BankTable newBank= new BankTable();
 * newBank.setAddress("MoonC_LTI"); newBank.setAge(BigDecimal.valueOf(40.0));
 * newBank.setCity("Califor_LTI"); newBank.setEmailId("charuLTI@gmail.com");
 * newBank.setFirstName("CharuLTI"); newBank.setMiddleName("SS");
 * newBank.setLastName("Sehgal"); newBank.setGender("Female");
 * newBank.setMobileNumber(BigDecimal.valueOf(996754231));
 * newBank.setPincode(BigDecimal.valueOf(186754)); newBank.setState("UPLTI");
 * newBank.setBankPassword("charu5678"); BankService.insertBankService(newBank);
 * }
 */