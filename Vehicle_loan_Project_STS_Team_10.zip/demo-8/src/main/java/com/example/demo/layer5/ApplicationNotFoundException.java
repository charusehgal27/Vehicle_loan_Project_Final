package com.example.demo.layer5;

public class ApplicationNotFoundException extends Exception  {


	public ApplicationNotFoundException(String msg) {
		super(msg);
	}


}


