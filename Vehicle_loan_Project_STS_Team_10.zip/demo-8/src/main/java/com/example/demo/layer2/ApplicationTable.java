package com.example.demo.layer2;


import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;


/**
 * The persistent class for the APPLICATION_TABLE database table.
 * 
 */
@Entity
@Table(name="APPLICATION_TABLE")
@NamedQuery(name="ApplicationTable.findAll", query="SELECT a FROM ApplicationTable a")
public class ApplicationTable implements Serializable {
	//private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="APPLICATION_ID")
	private int applicationId;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OF_APPLICATION")
	private Date dateOfApplication;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OF_APPROVAL")
	private Date dateOfApproval;

	@Column(name="LOAN_STATUS")
	private String loanStatus;

	//bi-directional one-to-one association to BankTable
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="BANK_ID")
	private BankTable bankTable;

	//bi-directional one-to-one association to EmploymentTable
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="EMPLOYMENT_ID")
	private EmploymentTable employmentTable;

	//bi-directional one-to-one association to LoanTable
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="LOAN_ID")
	private LoanTable loanTable;

	//bi-directional many-to-one association to UserTable
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="USER_ID")
	private UserTable userTable;

	//bi-directional one-to-one association to VehicleTable
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="VEHICLE_ID")
	private VehicleTable vehicleTable;

	public ApplicationTable() {
	}

	public int getApplicationId() {
		return this.applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public Date getDateOfApplication() {
		return this.dateOfApplication;
	}

	public void setDateOfApplication(Date dateOfApplication) {
		this.dateOfApplication = dateOfApplication;
	}

	public Date getDateOfApproval() {
		return this.dateOfApproval;
	}

	public void setDateOfApproval(Date dateOfApproval) {
		this.dateOfApproval = dateOfApproval;
	}

	public String getLoanStatus() {
		return this.loanStatus;
	}

	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}

	public BankTable getBankTable() {
		return this.bankTable;
	}

	public void setBankTable(BankTable bankTable) {
		this.bankTable = bankTable;
	}

	public EmploymentTable getEmploymentTable() {
		return this.employmentTable;
	}

	public void setEmploymentTable(EmploymentTable employmentTable) {
		this.employmentTable = employmentTable;
	}

	public LoanTable getLoanTable() {
		return this.loanTable;
	}

	public void setLoanTable(LoanTable loanTable) {
		this.loanTable = loanTable;
	}

	public UserTable getUserTable() {
		return this.userTable;
	}

	public void setUserTable(UserTable userTable) {
		this.userTable = userTable;
	}

	public VehicleTable getVehicleTable() {
		return this.vehicleTable;
	}

	public void setVehicleTable(VehicleTable vehicleTable) {
		this.vehicleTable = vehicleTable;
	}

	
	
	

}