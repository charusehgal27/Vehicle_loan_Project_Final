package com.example.demo.layer4;

import java.util.List;
import org.springframework.stereotype.Service;
import com.example.demo.layer2.BankTable;

@Service
public interface BankService {
	BankTable findBankbyIdService(int bankId);
	List<BankTable> findAllBanksService();
	void insertBankService(BankTable bref);
	void updateBankService(BankTable bref);
	void deleteBankService(int bankId);
}