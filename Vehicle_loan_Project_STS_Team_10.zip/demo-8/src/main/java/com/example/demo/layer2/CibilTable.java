package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;


/**
 * The persistent class for the CIBIL_TABLE database table.
 * 
 */
@Entity
@Table(name="CIBIL_TABLE")
@NamedQuery(name="CibilTable.findAll", query="SELECT c FROM CibilTable c")
public class CibilTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PANCARD_NUMBER")
	private String pancardNumber;

	@Column(name="CIBIL_SCORE")
	private BigDecimal cibilScore;

	//bi-directional one-to-one association to BankTable
	@OneToOne(mappedBy="cibilTable",cascade = CascadeType.ALL)
	private BankTable bankTable;

	public CibilTable() {
	}
	
	

	public CibilTable(String pancardNumber, BigDecimal cibilScore) {
		super();
		this.pancardNumber = pancardNumber;
		this.cibilScore = cibilScore;
	}
	



	public CibilTable(String pancardNumber, BigDecimal cibilScore, BankTable bankTable) {
		super();
		this.pancardNumber = pancardNumber;
		this.cibilScore = cibilScore;
		this.bankTable = bankTable;
	}



	public String getPancardNumber() {
		return this.pancardNumber;
	}

	public void setPancardNumber(String pancardNumber) {
		this.pancardNumber = pancardNumber;
	}

	public BigDecimal getCibilScore() {
		return this.cibilScore;
	}

	public void setCibilScore(BigDecimal cibilScore) {
		this.cibilScore = cibilScore;
	}

	@JsonIgnore
	public BankTable getBankTable() {
		return this.bankTable;
	}

	public void setBankTable(BankTable bankTable) {
		this.bankTable = bankTable;
	}

}