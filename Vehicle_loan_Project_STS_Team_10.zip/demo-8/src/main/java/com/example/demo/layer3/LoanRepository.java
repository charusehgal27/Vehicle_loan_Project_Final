package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.LoanTable;

@Repository
public interface LoanRepository {
	
	void insertLoan(LoanTable lRef);
	LoanTable selectLoanByLoanId(int loanId);
	List<LoanTable> selectAllLoans();
	void updateLoan(LoanTable lRef);
	void deleteLoan(int loanId);
}