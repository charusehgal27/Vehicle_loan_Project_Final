/*newUser.setAddress("MoonC_LTI");
		newUser.setAge(BigDecimal.valueOf(40.0));
		newUser.setCity("Califor_LTI");
		newUser.setEmailId("charuLTI@gmail.com");
		newUser.setFirstName("CharuLTI");
		newUser.setMiddleName("SS");
		newUser.setLastName("Sehgal");
		newUser.setGender("Female");
		newUser.setMobileNumber(BigDecimal.valueOf(996754231));
		newUser.setPincode(BigDecimal.valueOf(186754));
		newUser.setState("UPLTI");
		newUser.setUserPassword("charu5678");
		Just remeber this mistake always so I am commenting it instead of removing ok*/
package com.example.demo.layer5;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.layer2.UserTable;
import com.example.demo.layer4.UserService;

@CrossOrigin(origins="", value="")
@RestController
public class UserJPAController {

	@Autowired
	UserService UserService;
	
	public UserJPAController() {
		System.out.println("UserJPAController()....");
	}
	@PostMapping
	@RequestMapping(path="verifyUser/{email}/{password}")
	public UserTable verifyUser(@PathVariable ("email")String email,@PathVariable ("password")String password) {
		boolean found=false;
		UserTable userLogin=UserService.findUserByEmailService(email, password);
		found=true;
		if(found) {
			System.out.println("User found");
		}
		else {
			System.out.println("user not found");
		}
		return userLogin;
	}
	
	@GetMapping
	@RequestMapping(path="/getJPAUsers") //localhost:8080/getJPAUsers
	public List<UserTable> getAllUsers(){
		System.out.println("get all Users");
		return UserService.findAllUsersService();
	}
	
	
	@GetMapping
	@RequestMapping(path="/getJPAUser/{uno}") //localhost:8080/getJPAUser/401
	public UserTable getUser(@PathVariable("uno") int UsertoFind) throws UserNotFoundException
	{
		System.out.println("get User: "+UsertoFind);
		UserTable foundUser=null;
		foundUser = UserService.findUserbyIdService(UsertoFind);
		
		if(foundUser==null) {
			UserNotFoundException l= new UserNotFoundException("User "+UsertoFind+" not found");
		}
		
		return foundUser;
	}
	@PostMapping
	@RequestMapping(path="/addUser/{uAdd}/{uAge}/{uCity}/{uEmailId}/{uFname}/{uMname}/{uLname}/{uGender}/{uMnumber}/{uPincode}/{uState}/{uPassword}")
	public void addUser(@PathVariable("uAdd")String UserAdress,@PathVariable("uAge")BigDecimal UserAge,@PathVariable("uCity")String UserCity ,@PathVariable("uEmailId")String UserEmailID,@PathVariable("uFname")String UserFirstName,@PathVariable("uMname")String UserMiddleName,@PathVariable("uLname")String UserLastName,@PathVariable("uGender")String UserGender,@PathVariable("uMnumber")BigDecimal  UserMobileNumber,@PathVariable("uPincode")BigDecimal UserPincode,@PathVariable("uState")String UserState,@PathVariable("uPassword")String UserPassword)throws UserNotFoundException
	{
		System.out.println("Add User having details "+UserAdress+" "+UserAge+" "+UserCity +" "+UserEmailID+" "+ UserFirstName+" "+UserMiddleName+" "+ UserLastName+ " "+ UserGender+" "+UserMobileNumber+" " +UserPincode+" "+UserState +" "+UserPassword+" ");
		UserTable newUser= new UserTable();
		newUser.setAddress(UserAdress);
		newUser.setAge(UserAge);
		newUser.setCity(UserCity );
		newUser.setEmailId(UserEmailID);
		newUser.setFirstName( UserFirstName);
		newUser.setMiddleName(UserMiddleName);
		newUser.setLastName(UserLastName);
		newUser.setGender(UserGender);
		newUser.setMobileNumber(UserMobileNumber);
		newUser.setPincode(UserPincode);
		newUser.setState(UserState);
		newUser.setUserPassword(UserPassword);
		
		UserService.insertUserService(newUser);
		/*
		 * http://localhost:8080/addUser/kailashColony1/101/Pune1/xx1@gmail.com/charu1/ss1/sehgal1/Female/8887991141/123156/Maharasht1/1x3456
		 */
	}
	//   http://localhost:8080/addJPAUser
	@PostMapping
	@RequestMapping(path="/addJPAUser") 
	public void addUser2(@RequestBody UserTable UserInsert)throws UserNotFoundException
	{
		UserTable newUser= new UserTable();
		//newUser.setAddress("MoonC_LTI");
		//newUser.setAge(BigDecimal.valueOf(40.0));
		newUser.setAddress(UserInsert.getAddress());
		newUser.setAge(UserInsert.getAge());
		newUser.setCity(UserInsert.getCity());
		newUser.setEmailId(UserInsert.getEmailId());
		newUser.setFirstName(UserInsert.getFirstName());
		newUser.setMiddleName(UserInsert.getMiddleName());
		newUser.setLastName(UserInsert.getLastName());
		newUser.setGender(UserInsert.getGender());
		newUser.setMobileNumber(UserInsert.getMobileNumber());
		newUser.setPincode(UserInsert.getPincode());
		newUser.setState(UserInsert.getState());
		newUser.setUserPassword(UserInsert.getUserPassword());
		UserService.insertUserService(newUser);
	}
	
	@PostMapping
	@RequestMapping(path="/updateJPAUser")
	public void updateUser(@RequestBody UserTable UserUpdate)throws UserNotFoundException
	{
		System.out.println("update User for: "+UserUpdate.getUserId());
		boolean found=false;
		UserService.updateUserService(UserUpdate);
		found=true;
		
		if(found)
		{ System.out.println("record updated");
			}
		else {
			System.out.println("not found");
			UserNotFoundException l= new UserNotFoundException("User "+UserUpdate.getUserId()+" not found");
		    throw l;	
		}
		}
	
	@PostMapping
	@RequestMapping(path="/deleteUser")
	public void deleteUser(@RequestBody UserTable User)throws UserNotFoundException
	{
		System.out.println("delete User "+User.getUserId());
		boolean found=false;
		UserService.deleteUserService(User.getUserId());
		found=true;
		
		if(found)
		{ System.out.println("record DELETED");
			}
		else {
			System.out.println("not found");
			UserNotFoundException l= new UserNotFoundException("User "+User.getUserId()+" not found");
		    throw l;	
		}
		
	}
	
	
	@GetMapping
	@RequestMapping(path="getUsers/{email}")
	public UserTable verifyUser(@PathVariable ("email")String email) {
		boolean found=false;
		UserTable userLogin=UserService.findUserByEmailService(email);
		found=true;
		if(found) {
			System.out.println("User found");
		}
		else {
			System.out.println("user not found");
		}
		return userLogin;
	}
	
	
	@GetMapping
	@RequestMapping(path="/getUser/{email}") //localhost:8080/getUser/1/bb
	public UserTable getUser(@PathVariable("email") String UserEmailtoFind) throws UserNotFoundException
	{
		System.out.println("get User: "+UserEmailtoFind);
		UserTable foundUser=null;
		foundUser = UserService.findUserbyEmailId(UserEmailtoFind);
		
		if(foundUser==null) {
			UserNotFoundException l= new UserNotFoundException("User "+UserEmailtoFind+" not found");
		}
		
		return foundUser;
	}
	
	@PostMapping
	@RequestMapping(path="/getEmailAndPassword")
	public void getEmailAndPassword(@RequestBody UserTable userGet) throws UserNotFoundException
	{
		System.out.println("finding email and password");
		boolean found=false;
		String emailByUser=userGet.getEmailId();
		String pwdByUser=userGet.getUserPassword();
		
		List<UserTable> list=UserService.findAllUsersService();
		for(UserTable emAndPwd:list) {
			if(emAndPwd.getEmailId().equals(emailByUser) && emAndPwd.getUserPassword().equals(pwdByUser)) {
				found=true;
				System.out.println("Found ");    
			}
			else {
				System.out.println("not found");
				UserNotFoundException l= new UserNotFoundException("User "+userGet.getEmailId()+" not found");
			    throw l;
			}
		}
		
	}
	
}