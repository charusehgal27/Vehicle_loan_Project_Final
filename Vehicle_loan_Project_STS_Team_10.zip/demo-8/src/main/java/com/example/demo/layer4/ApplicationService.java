package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.ApplicationTable;

@Service
public interface ApplicationService {

	ApplicationTable findApplicationbyIdService(int appId);
	 List<ApplicationTable> findApplicationByEmailId(String emailId);
	 List<ApplicationTable> findAllApplicationsService();
	 void insertApplicationService(ApplicationTable aRef);
	 void updateApplicationStatusService(ApplicationTable aRef);
	 public void deleteApplicationService(int appId);
	
	// public void acceptLoanByAdminService(ApplicationTable aref);
	// public void rejectLoanByAdminService(ApplicationTable aref);
}