package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.UserTable;

@Repository
public interface UserRepository {

	UserTable findUserByEmail(String email,String pwd);
	void insertUser(UserTable uRef);
	UserTable selectUserByUserid(int uno);
	UserTable selectUserByEmailId(String emailId) ;
	List<UserTable> selectAllUsers();
	UserTable findUserByEmail(String email);
	void updateUser(UserTable uRef);
	void deleteUser(int uno);
}