package com.example.demo.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.BankTable;

@Repository
public class BankRepositoryImpl extends BaseRepository implements BankRepository {

	@Transactional
	public void insertBank(BankTable BRef) {
		super.persist(BRef);

	}

	@Transactional
	public BankTable selectBankByBankId(int Bid) {
		return super.find(BankTable.class, Bid);
	}

	@Transactional
	public List<BankTable> selectAllBanks() {
		return super.findAll("BankTable");
	}

	@Transactional
	public void updateBank(BankTable BRef) {
		super.merge(BRef);
	}

	@Transactional
	public void deleteBank(int Bid) {
		super.remove(BankTable.class, Bid);
		
	}

}