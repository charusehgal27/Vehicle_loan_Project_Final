
package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.UserTable;

@Service
public interface UserService {

	UserTable findUserByEmailService(String email, String password) ;
	UserTable findUserbyIdService(int userId);
	UserTable findUserbyEmailId(String emailId);
	UserTable findUserByEmailService(String email);
	List<UserTable> findAllUsersService();
	void insertUserService(UserTable uref);
	void updateUserService(UserTable uref);
	void deleteUserService(int userId);
}