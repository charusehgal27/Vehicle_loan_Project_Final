package com.example.demo.layer5;
public class LoanNotFoundException extends Exception  {
	public LoanNotFoundException(String msg) {
		super(msg);}}

