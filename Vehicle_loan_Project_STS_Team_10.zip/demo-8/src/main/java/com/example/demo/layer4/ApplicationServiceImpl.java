package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.ApplicationTable;
import com.example.demo.layer2.BankTable;
import com.example.demo.layer2.CibilTable;
import com.example.demo.layer2.EmploymentTable;
import com.example.demo.layer2.LoanTable;
import com.example.demo.layer2.UserTable;
import com.example.demo.layer2.VehicleTable;
import com.example.demo.layer3.AppRepository;
import com.example.demo.layer3.BankRepository;
import com.example.demo.layer3.UserRepository;

@Service
public class ApplicationServiceImpl implements ApplicationService {

	@Autowired
	AppRepository appRepo;
	@Autowired
	BankRepository bankRepo;

	@Autowired
	UserRepository userRepo;
	
	public List<ApplicationTable> findApplicationByEmailId(String emailId) {
	UserTable userTable= userRepo.findUserByEmail(emailId);
	String whereQuery="ApplicationTable a where a.userTable.userId = "+userTable.getUserId();
	return appRepo.selectQuery(whereQuery);
	}
	
	@Override
	public ApplicationTable findApplicationbyIdService(int appId) {
		// TODO Auto-generated method stub
		return appRepo.selectAppByAppNo(appId);
	}

	@Override
	public List<ApplicationTable> findAllApplicationsService() {
		// TODO Auto-generated method stub
		return appRepo.selectAllApp();
	}

	@Override
	public void insertApplicationService(ApplicationTable aRef) {
		// TODO Auto-generated method stub
/*
		ApplicationTable newApplication = new ApplicationTable();
		VehicleTable newVehicle = new VehicleTable();
		EmploymentTable newEmployment = new EmploymentTable();
		LoanTable newLoan = new LoanTable();
		BankTable newBank = new BankTable();
		CibilTable newCibil1 = new CibilTable();

		newApplication.setDateOfApplication(aRef.getDateOfApplication());
		newApplication.setDateOfApproval(aRef.getDateOfApproval());
		newApplication.setLoanStatus(aRef.getLoanStatus());

		// Bank Table
		newBank.setAccNumber(aRef.getBankTable().getAccNumber());
		newBank.setIfscCode(aRef.getBankTable().getIfscCode());
		newCibil1.setPancardNumber(aRef.getBankTable().getCibilTable().getPancardNumber());
		newCibil1.setCibilScore(aRef.getBankTable().getCibilTable().getCibilScore());
		newBank.setCibilTable(newCibil1);
		newApplication.setBankTable(newBank);

		// Vehicle Table
		newVehicle.setCarCompany(aRef.getVehicleTable().getCarCompany());
		newVehicle.setCarModel(aRef.getVehicleTable().getCarModel());
		newVehicle.setOnRoadPrice(aRef.getVehicleTable().getOnRoadPrice());
		newVehicle.setShowroomPrice(aRef.getVehicleTable().getShowroomPrice());
		newApplication.setVehicleTable(newVehicle);

		// Employment Table
		newEmployment.setEmpType(aRef.getEmploymentTable().getEmpType());
		newEmployment.setAnnualSalary(aRef.getEmploymentTable().getAnnualSalary());
		newEmployment.setExistingEmi(aRef.getEmploymentTable().getExistingEmi());
		newApplication.setEmploymentTable(newEmployment);

		// Loan Table
		newLoan.setLoanAmount(aRef.getLoanTable().getLoanAmount());
		newLoan.setLoanTenure(aRef.getLoanTable().getLoanTenure());
		newLoan.setProcessingFee(aRef.getLoanTable().getProcessingFee());
		newLoan.setRateOfInterest(aRef.getLoanTable().getRateOfInterest());
		newApplication.setLoanTable(newLoan);

		appRepo.insertApp(aRef);*/
		
			
			
			
			appRepo.insertApp(aRef);
			
			

		
	}

	@Override
	public void updateApplicationStatusService(ApplicationTable aRef) {
		// TODO Auto-generated method stub
		appRepo.updateApp(aRef);
	}

	/*
	 * @Override public void acceptLoanByAdminService(ApplicationTable aref) {
	 * 
	 * appRepo.updateApp(aref); }
	 * 
	 * @Override public void rejectLoanByAdminService(ApplicationTable aref) {
	 * ApplicationTable updateApp=new ApplicationTable(); long
	 * millis=System.currentTimeMillis(); java.sql.Date date=new
	 * java.sql.Date(millis); System.out.println(date);
	 * updateApp.setDateOfApproval(date); updateApp.setLoanStatus("Rejected");
	 * 
	 * }
	 */
	@Override
	public void deleteApplicationService(int appId) {
		// TODO Auto-generated method stub
		appRepo.deleteApp(appId);
	}


}