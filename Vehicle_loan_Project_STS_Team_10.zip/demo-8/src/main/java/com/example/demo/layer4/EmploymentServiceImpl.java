package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.EmploymentTable;
import com.example.demo.layer3.EmploymentRepository;


@Service
public class EmploymentServiceImpl implements EmploymentService {
	
	@Autowired
	EmploymentRepository EmpRepo;
	
	@Override	
	public EmploymentTable findEmpByIdService(int Empno) {
		System.out.println("findEmpByIdService() code is running...");
		return EmpRepo.selectEmployeeByEmployeeId(Empno);
	}

	@Override
	public void insertEmpService(EmploymentTable Eref) {
		System.out.println("insertEmpByIdService() code is running...");
		 EmpRepo.insertEmployee(Eref);
}
	
	@Override
	public void updateEmpService(EmploymentTable Eref) {
		System.out.println("updateEmpByIdService() code is running...");
		EmpRepo.updateEmployee(Eref);
	}
	
	@Override
	public void deleteEmpByIdService(int EmpId) {
		System.out.println("deleteEmpByIdService() code is running...");
		EmpRepo.deleteEmployee(EmpId);
	}
	
	@Override
	public List<EmploymentTable> findAllEmpService() {
		System.out.println("findAllEmpService() code is running...");
		return EmpRepo.selectAllEmployees();
	}		
}