package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.UserTable;
import com.example.demo.layer3.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepo;
	
	@Override
	public UserTable findUserByEmailService(String email, String password) {
		return userRepo.findUserByEmail(email, password);
	}
	@Override
	public UserTable findUserbyIdService(int userId) {
		// TODO Auto-generated method stub
		return userRepo.selectUserByUserid(userId);
	}
	@Override
	public UserTable findUserbyEmailId(String emailId) {
		System.out.println("get User: 1");
		return userRepo.selectUserByEmailId(emailId);
	}

	@Override
	public List<UserTable> findAllUsersService() {
		// TODO Auto-generated method stub
		return userRepo.selectAllUsers();
	}

	@Override
	public void insertUserService(UserTable uref) {
		// TODO Auto-generated method stub
        userRepo.insertUser(uref);
	}

	@Override
	public void updateUserService(UserTable uref) {
		// TODO Auto-generated method stub
        userRepo.updateUser(uref);
	}

	@Override
	public void deleteUserService(int userId) {
		// TODO Auto-generated method stub
        userRepo.deleteUser(userId);
	}

	@Override
	public UserTable findUserByEmailService(String email) {
		return userRepo.findUserByEmail(email);
	}
}