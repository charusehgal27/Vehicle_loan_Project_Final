package com.example.demo.layer4;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.layer2.BankTable;
import com.example.demo.layer3.BankRepository;

@Service
public class BankserviceImpl implements BankService {

	@Autowired
	BankRepository bankRepo;

	@Override
	public BankTable findBankbyIdService(int bankId) {
		return bankRepo.selectBankByBankId(bankId);
	}

	@Override
	public List<BankTable> findAllBanksService() {
		return bankRepo.selectAllBanks();
	}

	@Override
	public void insertBankService(BankTable bref) {
		bankRepo.insertBank(bref);
	}

	@Override
	public void updateBankService(BankTable bref) {
		bankRepo.updateBank(bref);
	}

	@Override
	public void deleteBankService(int bankId) {
		bankRepo.deleteBank(bankId);
	}

}
/* In the first function I was getting a useless error,then I removed complete line and typed it again it was gone same will 
 * do in dept one also
 * 
 * */
 