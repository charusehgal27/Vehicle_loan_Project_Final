package com.example.demo.layer3;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.UserTable;


@Repository
public class BaseRepository {
	
	@PersistenceContext
	EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	public BaseRepository() {
		System.out.println("BaseRepository()....");
	}
	
	@Transactional
	public void persist(Object obj) { //persist is a dummy/userdefined name
		
		try {
				entityManager.persist(obj);			
		} finally { entityManager.close(); }

	}
	
	@Transactional
	public <AnyClass> AnyClass find(Class<AnyClass> theClass, Serializable pk ) {
		AnyClass foundSavingsAccObj = null;
		try {			
			foundSavingsAccObj = entityManager.find(theClass, pk);	
			System.out.println(foundSavingsAccObj+"dhghfxfsghfhgxf");
		} finally { entityManager.close(); }
			return foundSavingsAccObj;
	}
	
	@Transactional
	public UserTable findE(String email) {
		try {			
			//Query query = entityManager.createQuery(" from "+ pojoName);
			Query query = entityManager.createQuery("select U from UserTable U where U.emailId =' "+email+"'");
			System.out.println(query.getResultList()+" dhghfxfsghfhgxf");
			return (UserTable)query.getSingleResult();
		} finally { entityManager.close(); }
	}
	
	@Transactional
	public <E> List  findAll(String pojoName) {
		try {			
			Query query = entityManager.createQuery(" from "+ pojoName);
			return query.getResultList();
		} finally { entityManager.close(); }
	}
	
	@Transactional
	public void merge(Object obj) {
		
		try {
			entityManager.merge(obj); //<--real call for jdbc here		
		} finally { entityManager.close(); }
		
	}
	@Transactional
	public UserTable findUserByEmail(String email,String pwd) {
		
		try {
			Query query=entityManager.createQuery("select u from UserTable u where u.emailId='"+email+"'and u.userPassword='"+pwd+"'");
			return (UserTable)query.getSingleResult();
		}
		finally {
			entityManager.close();
		}
	}
	
	@Transactional
	public <AnyClass> void remove(Class<AnyClass> theClass, Serializable pk) {
	try {
		AnyClass anyClass = entityManager.find(theClass, pk);
		if(anyClass==null) {
			throw new RuntimeException("Object not found to delete");
		}
		entityManager.remove(anyClass);
		} finally { entityManager.close(); }
	}
	@Transactional
	public UserTable findUserByEmail(String email) {
		
		try {
			Query query=entityManager.createQuery("select u from UserTable u where u.emailId='"+email+"'");
			return (UserTable)query.getSingleResult();
		}
		finally {
			entityManager.close();
		}
	}
}
// my uname was not working because it wa violating the primary key constraint...... we can send only primary key in the serializable pk 