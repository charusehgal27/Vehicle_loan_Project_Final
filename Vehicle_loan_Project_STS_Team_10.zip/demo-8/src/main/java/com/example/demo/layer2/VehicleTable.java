package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;


/**
 * The persistent class for the VEHICLE_TABLE database table.
 * 
 */
@Entity
@Table(name="VEHICLE_TABLE")
@NamedQuery(name="VehicleTable.findAll", query="SELECT v FROM VehicleTable v")
public class VehicleTable implements Serializable {
	private static final int serialVersionUID = 1;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="VEHICLE_ID")
	private int vehicleId;

	@Column(name="CAR_COMPANY")
	private String carCompany;

	@Column(name="CAR_MODEL")
	private String carModel;

	@Column(name="ON_ROAD_PRICE")
	private BigDecimal onRoadPrice;

	@Column(name="SHOWROOM_PRICE")
	private BigDecimal showroomPrice;

	//bi-directional one-to-one association to ApplicationTable
	@OneToOne(mappedBy="vehicleTable",cascade= CascadeType.ALL)
	private ApplicationTable applicationTable;

	public VehicleTable() {
	}

	public int getVehicleId() {
		return this.vehicleId;
	}

	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getCarCompany() {
		return this.carCompany;
	}

	public void setCarCompany(String carCompany) {
		this.carCompany = carCompany;
	}

	public String getCarModel() {
		return this.carModel;
	}

	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}

	public BigDecimal getOnRoadPrice() {
		return this.onRoadPrice;
	}

	public void setOnRoadPrice(BigDecimal onRoadPrice) {
		this.onRoadPrice = onRoadPrice;
	}

	public BigDecimal getShowroomPrice() {
		return this.showroomPrice;
	}

	public void setShowroomPrice(BigDecimal showroomPrice) {
		this.showroomPrice = showroomPrice;
	}
	
	@JsonIgnore
	public ApplicationTable getApplicationTable() {
		return this.applicationTable;
	}

	public void setApplicationTable(ApplicationTable applicationTable) {
		this.applicationTable = applicationTable;
	}

}