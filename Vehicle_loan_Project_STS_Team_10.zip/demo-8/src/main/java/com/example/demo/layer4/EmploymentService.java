package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.EmploymentTable;

@Service
public interface EmploymentService {
	EmploymentTable findEmpByIdService(int Empno);
	List<EmploymentTable> findAllEmpService();
	void updateEmpService(EmploymentTable Empno);
	void deleteEmpByIdService(int EmpId);
	void insertEmpService(EmploymentTable Empno);
}