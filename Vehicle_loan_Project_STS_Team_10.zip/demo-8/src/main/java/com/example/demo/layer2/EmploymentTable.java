package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;


/**
 * The persistent class for the EMPLOYMENT_TABLE database table.
 * 
 */
@Entity
@Table(name="EMPLOYMENT_TABLE")
@NamedQuery(name="EmploymentTable.findAll", query="SELECT e FROM EmploymentTable e")
public class EmploymentTable implements Serializable {
	private static final int serialVersionUID = 1;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="EMPLOYMENT_ID")
	private int employmentId;

	@Column(name="ANNUAL_SALARY")
	private BigDecimal annualSalary;

	@Column(name="EMP_TYPE")
	private String empType;

	@Column(name="EXISTING_EMI")
	private BigDecimal existingEmi;

	//bi-directional one-to-one association to ApplicationTable
	@OneToOne(mappedBy="employmentTable",cascade= CascadeType.ALL)
	private ApplicationTable applicationTable;

	public EmploymentTable() {
	}

	public int getEmploymentId() {
		return this.employmentId;
	}

	public void setEmploymentId(int employmentId) {
		this.employmentId = employmentId;
	}

	public BigDecimal getAnnualSalary() {
		return this.annualSalary;
	}

	public void setAnnualSalary(BigDecimal annualSalary) {
		this.annualSalary = annualSalary;
	}

	public String getEmpType() {
		return this.empType;
	}

	public void setEmpType(String empType) {
		this.empType = empType;
	}

	public BigDecimal getExistingEmi() {
		return this.existingEmi;
	}

	public void setExistingEmi(BigDecimal existingEmi) {
		this.existingEmi = existingEmi;
	}
	@JsonIgnore
	public ApplicationTable getApplicationTable() {
		return this.applicationTable;
	}

	public void setApplicationTable(ApplicationTable applicationTable) {
		this.applicationTable = applicationTable;
	}

}