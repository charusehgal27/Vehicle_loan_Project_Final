package com.example.demo.layer5;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.example.demo.layer2.EmploymentTable;
import com.example.demo.layer2.LoanTable;
import com.example.demo.layer2.VehicleTable;
import com.example.demo.layer4.EmploymentService;

@CrossOrigin(origins = "", value = "")
@RestController
public class EmpJPAController {
	

	@Autowired
	EmploymentService EmpService; 
	
	public EmpJPAController() {
		System.out.println("EmpJPAController()....");		
	}
	
	@GetMapping
	@RequestMapping(path="/getJPAEmp/{Eno}") // localhost:8085/getJPAEmp/10
	public EmploymentTable getEmployment(@PathVariable("Eno") int EmpNumberToFind) throws IdNotFoundException
	{
		System.out.println("getEmp : "+EmpNumberToFind);
		EmploymentTable foundEmp = null;
		foundEmp = EmpService.findEmpByIdService(EmpNumberToFind);
	
		if(foundEmp == null) {
			IdNotFoundException d = new IdNotFoundException("Emp Number Not Found "+EmpNumberToFind);
		}
		return foundEmp;
	}
	
	@PostMapping
	@RequestMapping(path="/addJPAEmp/{et}/{es}/{ee}")   // localhost:8080/addJPAEmp/Salaried/1000500/5678
	public void addEmployment(@PathVariable("et") String EmpType, @PathVariable("es") BigDecimal salary, @PathVariable("ee") BigDecimal ExistEmi ) throws IdNotFoundException 
	{
		System.out.println("addEmp : "+EmpType+" "+salary);
		EmploymentTable newEmp = new EmploymentTable();
		newEmp.setEmpType(EmpType);
		newEmp.setAnnualSalary(salary);
		newEmp.setExistingEmi(ExistEmi);
		EmpService.insertEmpService(newEmp);		
	}	
	
	@PostMapping
	@RequestMapping(path="/addJPAEmp2")   // localhost:8080/addJPAEmp2
	public void addEmployment(@RequestBody EmploymentTable empToAdd ) throws IdNotFoundException 
	{
		
		EmploymentTable newEmp = new EmploymentTable();
		newEmp.setEmpType(empToAdd.getEmpType());
		newEmp.setAnnualSalary(empToAdd.getAnnualSalary());
		newEmp.setExistingEmi(empToAdd.getExistingEmi());
		EmpService.insertEmpService(newEmp);		
	}
	
	@GetMapping
	@RequestMapping(path="/getJPAEmps")  //localhost:8085/getJPAEmps
	public List<EmploymentTable> getAllEmployment(){
		System.out.println("get all Emps");
		return EmpService.findAllEmpService();
	}
	
	
	@PostMapping
	@RequestMapping(path="/deleteEmp") //localhost:8085/deleteEmp
	public void deleteEmp(@RequestBody EmploymentTable Emp)throws IdNotFoundException
	{
		System.out.println("delete Emp "+Emp.getEmploymentId());
		boolean found=false;
		EmpService.deleteEmpByIdService(Emp.getEmploymentId());
		found=true;
		
		if(found)
		{ System.out.println("record deleted");
			}
		else {
			System.out.println("not found");
			IdNotFoundException E= new IdNotFoundException("Emp "+Emp.getEmploymentId()+" not found");
		    throw E;	
		}	
	}
	
	@PostMapping
	@RequestMapping(path="/updateEmp") //localhost:8085/updateEmps
	public void updateEmp(@RequestBody EmploymentTable Emp)throws IdNotFoundException
	{
		System.out.println("update Emp "+Emp.getEmploymentId());
		boolean found=false;
		EmpService.updateEmpService(Emp);
		found=true;
		
		if(found)
		{ System.out.println("record updated");
			}
		else {
			System.out.println("not found");
			IdNotFoundException E= new IdNotFoundException("Emp "+Emp.getEmploymentId()+" not found");
		    throw E;	
		}
		
	}
	
}