package com.example.demo.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.VehicleTable;

@Repository
public class VehicleRepositoryImpl extends BaseRepository implements VehicleRepository {

	@Transactional
	public void insertVehicle(VehicleTable VRef) {
		super.persist(VRef);

	}

	@Transactional
	public VehicleTable selectVehicleByVehicleid(int Vid) {
		return super.find(VehicleTable.class, Vid);
	}

	@Transactional
	public List<VehicleTable> selectAllVehicles() {
		return super.findAll("VehicleTable");
	}

	@Transactional
	public void updateVehicle(VehicleTable VRef) {
		super.merge(VRef);

	}

	@Transactional
	public void deleteVehicle(int Vid) {
		super.remove(VehicleTable.class, Vid);

	}

}