package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the USER_TABLE database table.
 * 
 */
@Entity
@Table(name="USER_TABLE")
@NamedQuery(name="UserTable.findAll", query="SELECT u FROM UserTable u")
public class UserTable implements Serializable {
	private static final int serialVersionUID = 1;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="USER_ID")
	private int userId;

	private String address;

	private BigDecimal age;

	private String city;

	@Column(name="EMAIL_ID")
	private String emailId;

	@Column(name="FIRST_NAME")
	private String firstName;

	private String gender;

	@Column(name="LAST_NAME")
	private String lastName;

	@Column(name="MIDDLE_NAME")
	private String middleName;

	@Column(name="MOBILE_NUMBER")
	private BigDecimal mobileNumber;

	private BigDecimal pincode;

	@Column(name="STATE")
	private String state;

	@Column(name="USER_PASSWORD")
	private String userPassword;

	//bi-directional many-to-one association to ApplicationTable
	@OneToMany(mappedBy="userTable", fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	private List<ApplicationTable> applicationTables;

	public UserTable() {
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public BigDecimal getAge() {
		return this.age;
	}

	public void setAge(BigDecimal age) {
		this.age = age;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public BigDecimal getMobileNumber() {
		return this.mobileNumber;
	}

	public void setMobileNumber(BigDecimal mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public BigDecimal getPincode() {
		return this.pincode;
	}

	public void setPincode(BigDecimal pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getUserPassword() {
		return this.userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	@JsonIgnore
	public List<ApplicationTable> getApplicationTables() {
		return this.applicationTables;
	}

	public void setApplicationTables(List<ApplicationTable> applicationTables) {
		this.applicationTables = applicationTables;
	}

	
	public ApplicationTable addApplicationTable(ApplicationTable applicationTable) {
		getApplicationTables().add(applicationTable);
		applicationTable.setUserTable(this);

		return applicationTable;
	}

	public ApplicationTable removeApplicationTable(ApplicationTable applicationTable) {
		getApplicationTables().remove(applicationTable);
		applicationTable.setUserTable(null);

		return applicationTable;
	}

}