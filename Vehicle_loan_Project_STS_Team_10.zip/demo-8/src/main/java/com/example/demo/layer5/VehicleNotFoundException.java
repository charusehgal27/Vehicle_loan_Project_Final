package com.example.demo.layer5;

public class VehicleNotFoundException extends Exception {
	public VehicleNotFoundException(String msg) {
	super(msg);
	}

}



	