package com.example.demo.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.CibilTable;

@Repository
public class CibilRepositoryImpl extends BaseRepository implements CibilRepository {

	@Transactional
	public void insertCibil(CibilTable CRef) {
		super.persist(CRef);

	}

	@Transactional
	public CibilTable selectCibilByPancard(String PanNum) {
		return super.find(CibilTable.class, PanNum);
	}

	@Transactional
	public List<CibilTable> selectAllCibil() {
		return super.findAll("CibilTable");
	}

	@Transactional
	public void updateCibil(CibilTable CRef) {
		super.merge(CRef);
	}

	@Transactional
	public void deleteCibil(String PanNum) {
		super.remove(CibilTable.class, PanNum);
	}

}