package com.example.demo.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.EmploymentTable;

@Repository
public class EmploymentRepositoryImpl extends BaseRepository implements EmploymentRepository {
	
	public EmploymentRepositoryImpl() {
		System.out.println("EmploymentRepositoryImpl() implementation");
	}

	@Transactional
	public void insertEmployee(EmploymentTable eRef) {
		// TODO Auto-generated method stub
		super.persist(eRef);
	}

	@Transactional
	public EmploymentTable selectEmployeeByEmployeeId(int empId) {
		// TODO Auto-generated method stub
		return super.find(EmploymentTable.class, empId);
	}

	@Transactional
	public List<EmploymentTable> selectAllEmployees() {
		// TODO Auto-generated method stub
		return super.findAll("EmploymentTable");
	}

	@Transactional
	public void updateEmployee(EmploymentTable eRef) {
		// TODO Auto-generated method stub
		super.merge(eRef);

	}

	@Transactional
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		super.remove(EmploymentTable.class,empId );

	}

}