package com.example.demo.layer5;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.ApplicationTable;
import com.example.demo.layer2.BankTable;
import com.example.demo.layer2.CibilTable;
import com.example.demo.layer2.EmploymentTable;
import com.example.demo.layer2.LoanTable;
import com.example.demo.layer2.UserTable;
import com.example.demo.layer2.VehicleTable;
import com.example.demo.layer4.ApplicationService;
import com.example.demo.layer4.BankService;
import com.example.demo.layer4.UserService;

@CrossOrigin(origins = "", value = "")
@RestController
public class ApplicationJPAController {

	@Autowired
	ApplicationService applicationService;
	@Autowired
	BankService bankService;
	@Autowired
	UserService userService;

	public ApplicationJPAController() {
		System.out.println("ApplicationJPAController()....");
	}

	
	@GetMapping
	@RequestMapping(path = "/getJPAApplication/{ano}") // localhost:8080/getJPAApplication/801
	public ApplicationTable getApplicationTable(@PathVariable("ano") int applicationtoFind)
			throws ApplicationNotFoundException {
		System.out.println("get application: " + applicationtoFind);
		ApplicationTable foundApplication = null;
		foundApplication = applicationService.findApplicationbyIdService(applicationtoFind);

		if (foundApplication == null) {
			ApplicationNotFoundException a = new ApplicationNotFoundException(
					"Loan " + applicationtoFind + " not found");

		}

		return foundApplication;
	}
	
	 @PostMapping
		@RequestMapping(path="/acceptLoanApplication/{appId}")
		public void acceptLoanApplication(@PathVariable("appId") int ApplicationId)throws ApplicationNotFoundException 
		{
			boolean found = false;
			long millis=System.currentTimeMillis();  
			java.sql.Date date=new java.sql.Date(millis);  
			System.out.println(date);
			ApplicationTable appTable=applicationService.findApplicationbyIdService(ApplicationId);
			appTable.setLoanStatus("Accepted");
			appTable.setDateOfApproval(date);
		
			applicationService.updateApplicationStatusService(appTable);
			found = true;
			if (found) {
				System.out.println("Record modified...");
				
			} else {
				System.out.println("Not found");
				ApplicationNotFoundException appNotFoundEx = new ApplicationNotFoundException(
						"Application Number Not Found " + appTable.getApplicationId());
				throw appNotFoundEx;
			}	
		}
	// http://localhost:8080/addJPAApplication/40/OPERATIONS/CHENNAI
	 @GetMapping(path = "/getApplicationByemail")
	 public List<ApplicationTable> getAllApplicationsByEmail(@RequestBody UserTable getUsers ) {
	 System.out.println("get all loans by email");
	 String email=getUsers.getEmailId();
	 return applicationService.findApplicationByEmailId(email);
	 }
	 
	 @PostMapping
	 @RequestMapping(path = "/addJPAApplication/{email}")
	 public void addApplication(@RequestBody ApplicationTable appToInsert,@PathVariable ("email") String email) throws ApplicationNotFoundException {

	 ApplicationTable newApplication = new ApplicationTable();
	 VehicleTable newVehicle= new VehicleTable();
	 EmploymentTable newEmployment=new EmploymentTable();
	 LoanTable newLoan=new LoanTable();
	 BankTable newBank=new BankTable();
	 CibilTable newCibil1=new CibilTable();
	 UserTable user= userService.findUserByEmailService(email);
	 appToInsert.setUserTable(user);
	 newApplication.setDateOfApplication(appToInsert.getDateOfApplication());
	 newApplication.setDateOfApproval(appToInsert.getDateOfApproval());
	 newApplication.setLoanStatus(appToInsert.getLoanStatus());
	 // Bank Table
	 System.out.println(appToInsert.getBankTable().getAccNumber());
	 newBank.setAccNumber(appToInsert.getBankTable().getAccNumber());
	 newBank.setIfscCode(appToInsert.getBankTable().getIfscCode());
	 newCibil1.setPancardNumber(appToInsert.getBankTable().getCibilTable().getPancardNumber());
	 newCibil1.setCibilScore(appToInsert.getBankTable().getCibilTable().getCibilScore());
	 newBank.setCibilTable(newCibil1);
	 newApplication.setBankTable(newBank);
	 //Vehicle Table
	 newVehicle.setCarCompany(appToInsert.getVehicleTable().getCarCompany());
	 newVehicle.setCarModel(appToInsert.getVehicleTable().getCarModel());
	 newVehicle.setOnRoadPrice(appToInsert.getVehicleTable().getOnRoadPrice());
	 newVehicle.setShowroomPrice(appToInsert.getVehicleTable().getShowroomPrice());
	 newApplication.setVehicleTable(newVehicle);
	 //Employment Table
	 newEmployment.setEmpType(appToInsert.getEmploymentTable().getEmpType());
	 newEmployment.setAnnualSalary(appToInsert.getEmploymentTable().getAnnualSalary());
	 newEmployment.setExistingEmi(appToInsert.getEmploymentTable().getExistingEmi());
	 newApplication.setEmploymentTable(newEmployment);
	 //Loan Table
	 newLoan.setLoanAmount(appToInsert.getLoanTable().getLoanAmount());
	 newLoan.setLoanTenure(appToInsert.getLoanTable().getLoanTenure());
	 newLoan.setProcessingFee(appToInsert.getLoanTable().getProcessingFee());
	 newLoan.setRateOfInterest(appToInsert.getLoanTable().getRateOfInterest());
	 newApplication.setLoanTable(newLoan);
	 applicationService.insertApplicationService(appToInsert);
	 }	
	
	
	
	@PostMapping
	@RequestMapping(path="/rejectLoanApplication/{appId}")
	public void rejectLoanApplication(@PathVariable("appId") int ApplicationId)throws ApplicationNotFoundException 
	{
		boolean found = false;
		long millis=System.currentTimeMillis();  
		java.sql.Date date=new java.sql.Date(millis);  
		System.out.println(date);
		ApplicationTable appTable=applicationService.findApplicationbyIdService(ApplicationId);
		appTable.setLoanStatus("Rejected");
		appTable.setDateOfApproval(date);
		
		applicationService.updateApplicationStatusService(appTable);
		found = true;

		if (found) {
			System.out.println("Record modified...");
			

		} else {
			System.out.println("Not found");
			ApplicationNotFoundException appNotFoundEx = new ApplicationNotFoundException(
					"Application Number Not Found " + appTable.getApplicationId());
			throw appNotFoundEx;
		}
		
	}

	@GetMapping
	@RequestMapping(path = "/getJPAApplications") // localhost:8080/getJPAApplications
	public List<ApplicationTable> getAllApplications() {
		System.out.println("get all loans");
		return applicationService.findAllApplicationsService();
	}	

	// http://localhost:8080/addJPAApplication/40/OPERATIONS/CHENNAI
	/*@PostMapping
	@RequestMapping(path = "/addJPAApplication")
public void addApplication(@RequestBody ApplicationTable appToInsert) throws ApplicationNotFoundException {
//		ApplicationTable newApplication = new ApplicationTable();
//		VehicleTable newVehicle= new VehicleTable();
//		EmploymentTable newEmployment=new EmploymentTable();
//		LoanTable newLoan=new LoanTable();
//		BankTable newBank=new BankTable();
//		CibilTable newCibil1= new CibilTable();
		
		// Application Table
//		newApplication.setDateOfApplication(appToInsert.getDateOfApplication());
//		newApplication.setDateOfApproval(appToInsert.getDateOfApproval());
//		newApplication.setLoanStatus(appToInsert.getLoanStatus());
		
		
		/*
		//Vehicle Table
		newVehicle.setCarCompany(appToInsert.getVehicleTable().getCarCompany());
		newVehicle.setCarModel(appToInsert.getVehicleTable().getCarModel());
		newVehicle.setOnRoadPrice(appToInsert.getVehicleTable().getOnRoadPrice());
		newVehicle.setShowroomPrice(appToInsert.getVehicleTable().getShowroomPrice());
		newVehicle.setApplicationTable(newApplication);
		
		//Employment Table
		newEmployment.setEmpType(appToInsert.getEmploymentTable().getEmpType());
		newEmployment.setAnnualSalary(appToInsert.getEmploymentTable().getAnnualSalary());
		newEmployment.setExistingEmi(appToInsert.getEmploymentTable().getExistingEmi());
		newEmployment.setApplicationTable(newApplication);
		
		//Loan Table
		newLoan.setLoanAmount(appToInsert.getLoanTable().getLoanAmount());
		newLoan.setLoanTenure(appToInsert.getLoanTable().getLoanTenure());
		newLoan.setProcessingFee(appToInsert.getLoanTable().getProcessingFee());
		newLoan.setRateOfInterest(appToInsert.getLoanTable().getRateOfInterest());
		newLoan.setApplicationTable(newApplication);
		
		//Bank Table
		newBank.setAccNumber(appToInsert.getBankTable().getAccNumber());
		newBank.setIfscCode(appToInsert.getBankTable().getIfscCode());
		newBank.setApplicationTable(newApplication);
		*
//		newBank.setAccNumber(appToInsert.getBankTable().getAccNumber());
//		newBank.setIfscCode(appToInsert.getBankTable().getIfscCode());
//		newBank.setApplicationTable(newApplication);


		//bankService.insertBankService(newBank);
		applicationService.insertApplicationService(appToInsert);
	}*/

	// http://localhost:8080/modifyJPAApplication
	@PostMapping
	@RequestMapping(path = "/modifyJPAApplication") //
	public void modifyApplicationByAdmin(@RequestBody ApplicationTable appToModify) throws ApplicationNotFoundException {
		System.out.println("modifyApplication: " + appToModify.getLoanStatus() + " " + appToModify.getApplicationId());
		boolean found = false;
		applicationService.updateApplicationStatusService(appToModify);
		found = true;

		if (found) {
			System.out.println("Record modified...");

		} else {
			System.out.println("Not found");
			ApplicationNotFoundException appNotFoundEx = new ApplicationNotFoundException(
					"Application Number Not Found " + appToModify.getApplicationId());
			throw appNotFoundEx;
		}

	}

	@PostMapping
	@RequestMapping(path="/deleteJPAApplication")
	public void deleteApplication(@RequestBody ApplicationTable appToDelete)throws ApplicationNotFoundException
	{
		System.out.println("delete application "+appToDelete.getApplicationId());
		boolean found=false;
		applicationService.deleteApplicationService(appToDelete.getApplicationId());
		found=true;
		
		if(found)
		{ System.out.println("record updated");
			}
		else {
			System.out.println("not found");
			ApplicationNotFoundException aex= new ApplicationNotFoundException("Loan "+appToDelete.getApplicationId()+" not found");
		    throw aex;	
		}
		
	}
	/*@PostMapping
	@RequestMapping(path = "/addJPAApplication/{email}")
	public void addApplication(@RequestBody ApplicationTable appToInsert,@PathVariable ("email") String email) throws ApplicationNotFoundException {

     	ApplicationTable newApplication = new ApplicationTable();
		VehicleTable newVehicle= new VehicleTable();
		EmploymentTable newEmployment=new EmploymentTable();
		LoanTable newLoan=new LoanTable();
		BankTable newBank=new BankTable();
		CibilTable newCibil1=new CibilTable();
		
		
		UserTable user= userService.findUserByEmailService(email);
		appToInsert.setUserTable(user);
		
		newApplication.setDateOfApplication(appToInsert.getDateOfApplication());
		newApplication.setDateOfApproval(appToInsert.getDateOfApproval());
		newApplication.setLoanStatus(appToInsert.getLoanStatus());
		
		// Bank Table
		System.out.println(appToInsert.getBankTable().getAccNumber());
		newBank.setAccNumber(appToInsert.getBankTable().getAccNumber());
		newBank.setIfscCode(appToInsert.getBankTable().getIfscCode());
		newCibil1.setPancardNumber(appToInsert.getBankTable().getCibilTable().getPancardNumber());
		newCibil1.setCibilScore(appToInsert.getBankTable().getCibilTable().getCibilScore());
		newBank.setCibilTable(newCibil1);
		newApplication.setBankTable(newBank);
		
		//Vehicle Table
				newVehicle.setCarCompany(appToInsert.getVehicleTable().getCarCompany());
				newVehicle.setCarModel(appToInsert.getVehicleTable().getCarModel());
				newVehicle.setOnRoadPrice(appToInsert.getVehicleTable().getOnRoadPrice());
				newVehicle.setShowroomPrice(appToInsert.getVehicleTable().getShowroomPrice());
				newApplication.setVehicleTable(newVehicle);
				
				//Employment Table
				newEmployment.setEmpType(appToInsert.getEmploymentTable().getEmpType());
				newEmployment.setAnnualSalary(appToInsert.getEmploymentTable().getAnnualSalary());
				newEmployment.setExistingEmi(appToInsert.getEmploymentTable().getExistingEmi());
				newApplication.setEmploymentTable(newEmployment);
				
				//Loan Table
				newLoan.setLoanAmount(appToInsert.getLoanTable().getLoanAmount());
				newLoan.setLoanTenure(appToInsert.getLoanTable().getLoanTenure());
				newLoan.setProcessingFee(appToInsert.getLoanTable().getProcessingFee());
				newLoan.setRateOfInterest(appToInsert.getLoanTable().getRateOfInterest());
				newApplication.setLoanTable(newLoan);
		
		
		
		
		
		applicationService.insertApplicationService(appToInsert);
	}*/

}