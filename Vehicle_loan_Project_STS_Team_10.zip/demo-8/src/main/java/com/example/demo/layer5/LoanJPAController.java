package com.example.demo.layer5;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.LoanTable;
import com.example.demo.layer4.LoanService;

@CrossOrigin(origins="", value="")
@RestController
public class LoanJPAController {

	@Autowired
	LoanService loanService;
	
	public LoanJPAController() {
		System.out.println("LoanJPAController()....");
	}
	
	@GetMapping
	@RequestMapping(path="/getJPALoans") //localhost:8080/getJPALoans
	public List<LoanTable> getAllLoans(){
		System.out.println("get all loans");
		return loanService.findAllLoansService();
	}
	
	@GetMapping
	@RequestMapping(path="/getJPALoan/{lno}") //localhost:8080/getJPALoan/401
	public LoanTable getLoan(@PathVariable("lno") int loantoFind) throws LoanNotFoundException
	{
		System.out.println("get Loan: "+loantoFind);
		LoanTable foundLoan=null;
		foundLoan = loanService.findLoanbyIdService(loantoFind);
		
		if(foundLoan==null) {
			LoanNotFoundException l= new LoanNotFoundException("Loan "+loantoFind+" not found");
		}
		
		return foundLoan;
	}
	
	@PostMapping
	@RequestMapping(path="/addLoan/{lamt}/{ltenure}/{roi}/{pfee}")
	public void addLoan(@PathVariable("lamt")BigDecimal loanAmt,@PathVariable("ltenure")BigDecimal loanTenure,@PathVariable("roi")BigDecimal rateOfInterest ,@PathVariable("pfee")BigDecimal processingFee)throws LoanNotFoundException
	{
		System.out.println("Add Loan "+loanAmt+" "+loanTenure+" "+rateOfInterest+" "+processingFee);
		LoanTable newLoan= new LoanTable();
		newLoan.setLoanAmount(loanAmt);
		newLoan.setLoanTenure(loanTenure);
		newLoan.setRateOfInterest(rateOfInterest);
		newLoan.setProcessingFee(processingFee);
		loanService.insertLoanService(newLoan);
	}
	
	@PostMapping
	@RequestMapping(path="/addJPALoan") 
	public void addLoan2(@RequestBody LoanTable loanInsert)throws LoanNotFoundException
	{
		LoanTable newLoan= new LoanTable();
		newLoan.setLoanAmount(loanInsert.getLoanAmount());
		newLoan.setLoanTenure(loanInsert.getLoanTenure());
		newLoan.setRateOfInterest(loanInsert.getRateOfInterest());
		newLoan.setProcessingFee(loanInsert.getProcessingFee());
		loanService.insertLoanService(newLoan);
	}
	
	@PostMapping
	@RequestMapping(path="/updateJPALoan")
	public void updateLoan(@RequestBody LoanTable loanUpdate)throws LoanNotFoundException
	{
		System.out.println("update Loan for: "+loanUpdate.getLoanId());
		boolean found=false;
		loanService.updateLoanService(loanUpdate);
		found=true;
		
		if(found)
		{ System.out.println("record updated");
			}
		else {
			System.out.println("not found");
			LoanNotFoundException l= new LoanNotFoundException("Loan "+loanUpdate.getLoanId()+" not found");
		    throw l;	
		}
		}
	
	@PostMapping
	@RequestMapping(path="/deleteJPALoan")
	public void deleteLoan(@RequestBody LoanTable loan)throws LoanNotFoundException
	{
		System.out.println("delete loan "+loan.getLoanId());
		boolean found=false;
		loanService.deleteLoanService(loan.getLoanId());
		found=true;
		
		if(found)
		{ System.out.println("record updated");
			}
		else {
			System.out.println("not found");
			LoanNotFoundException l= new LoanNotFoundException("Loan "+loan.getLoanId()+" not found");
		    throw l;	
		}
		
	}
	
}