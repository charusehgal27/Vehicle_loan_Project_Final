package com.example.demo.layer3;

import java.util.HashMap;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.example.demo.layer2.UserTable;
import com.example.demo.layer2.VehicleTable;


@Repository
public class UserRepositoryImpl extends BaseRepository implements UserRepository {
	
	public UserRepositoryImpl() {
		System.out.println("UserRepositoryImpl() implementation");
	}
	@Transactional
	 public UserTable findUserByEmail(String email,String pwd) {
		 return super.findUserByEmail(email, pwd);
	 }
	 @Transactional
	public void insertUser(UserTable uRef) {
		super.persist(uRef);
	}
	 
	 @Transactional
	public UserTable selectUserByUserid(int uno) {
		return super.find(UserTable.class, uno);
	}
	 public int getIdFromEmail(String email) {
		 
		 	HashMap<String, Integer> map = new HashMap<>();
		 	map.put(email, 183);
	        map.put("vishal", 10);
	        map.put("sachin", 30);
	        map.put("vaibhav", 20);
	        return map.get(email);
	 }
	 @Transactional
	 public UserTable selectUserByEmailId(String emailId) {
		 // Email ID --> id
		 int userId = 1;
		 System.out.println("get User: 2");
		 //UserTable usertable = super.findE(emailId);
		 userId = getIdFromEmail(emailId);
		 System.out.println("get User: 3");
		 //userId = L.get(0);
		 return super.find(UserTable.class, userId);
	 }
	 @Transactional
	public List<UserTable> selectAllUsers() {
		return super.findAll("UserTable");
	}
	 
	 @Transactional
	public void updateUser(UserTable uRef) {
		super.merge(uRef);
	}
	 
	 @Transactional
	public void deleteUser(int uno) {
		super.remove(UserTable.class, uno);
	}

	 @Transactional
	 public UserTable findUserByEmail(String email) {
		 return super.findUserByEmail(email);
	 }
}